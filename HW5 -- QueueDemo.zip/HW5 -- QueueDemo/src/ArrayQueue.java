public class ArrayQueue {
    public int[] stuff;
    public int front;
    public int size;

    public ArrayQueue() {
        stuff = new int[2];
    }

    public void add(int data) {
        if (stuff.length == size) {
            resize();
        }
        stuff[(front + size) % stuff.length] = data;
        size++;
    }

    private void resize() {
        int[] stuff2 = new int[stuff.length * 2];
        for (int i = 0; i < stuff.length; i++) {
            stuff2[i] = stuff[(front + i) % stuff.length];
        }
        stuff = stuff2;
        front = 0;
    }

    public int remove() {
        emptyCheck();
        int temp = stuff[front];
        front = (front + 1) % stuff.length;
        size--;
        return temp;
    }

    public int element() {
        emptyCheck();
        return stuff[front];
    }

    public int size() {
        return size;
    }

    public int capacity() {
        return stuff.length;
    }

    private void emptyCheck() {
        if (size == 0) {
            throw new IllegalStateException("Queue is empty.");
        }
    }
}
