public class ArrayQueueVisualization {
    public static void main(String[] args) {
        ArrayQueue q = new ArrayQueue();

        // Function 1: q.add(2)
        q.add(2);
        visualizeState(q);

        // Function 2: q.remove()
        q.remove();
        visualizeState(q);

        // Function 3: q.add(7)
        q.add(7);
        visualizeState(q);

        // Function 4: q.add(8)
        q.add(8);
        visualizeState(q);

        // Function 5: q.add(1)
        q.add(1);
        visualizeState(q);

        // Function 6: q.add(3)
        q.add(3);
        visualizeState(q);
    }

    // Function to visualize the state of the ArrayQueue
    public static void visualizeState(ArrayQueue q) {
        System.out.println("Front: " + q.front);
        System.out.println("Size: " + q.size());
        System.out.println("Length: " + q.capacity());
        System.out.print("Array: [");

        int length = q.capacity();
        for (int i = 0; i < length; i++) {
            if (i > 0) {
                System.out.print(", ");
            }
            System.out.print(q.stuff[i]);
        }

        System.out.println("]\n");
    }
}