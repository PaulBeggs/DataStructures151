package matrix.model;

import javafx.scene.control.TextField;

import javafx.scene.layout.GridPane;

import static javafx.geometry.Pos.CENTER;

public class MatrixView {
    private Matrix matrix;

    public MatrixView(Matrix matrix) {
        this.matrix = matrix;
    }

    public void displayOnGridPane(GridPane gridPane, boolean isEditable) {
        gridPane.getChildren().clear();

        int numRows = matrix.getRows();
        int numCols = matrix.getCols();

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                double value = matrix.getValue(row, col);

                TextField cell = new TextField(String.valueOf(value));
                cell.setMinHeight(50);
                cell.setMinWidth(50);
                cell.setAlignment(CENTER);
                cell.setEditable(isEditable);

                // Add the cell to the gridPane
                gridPane.add(cell, col, row);
            }
        }
    }


    public void update() {

    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("MatrixView [\n");
        int numRows = matrix.getRows();
        int numCols = matrix.getCols();

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                stringBuilder.append(matrix.getValue(row, col)).append("\t");
            }
            stringBuilder.append("\n");
        }

        stringBuilder.append("]");
        return stringBuilder.toString();
    }
}