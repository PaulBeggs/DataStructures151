package matrix.model;

public interface MatrixOperations {
    double[][] getMatrix();
    int getRows();
    int getCols();
    boolean isValidRow(int row);
}
