package matrix.model;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MatrixFileHandler {
    private static final Map<String, Matrix> matrices = new HashMap<>();

    public static void saveMatrixToFile(String fileName, List<List<String>> matrixData) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false))) {

            for (List<String> row : matrixData) {
                String line = String.join(" ", row);
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void clearAndSaveMatrixToFile(String fileName, Matrix matrix) {
        // Delete the existing file
        File file = new File(fileName);
        file.delete();

        // Save the new matrix data to the file
        saveMatrixToFile(fileName, matrix);
    }

    private static void saveMatrixToFile(String fileName, Matrix matrix) {
        List<List<String>> matrixData = new ArrayList<>();

        // Convert the matrix to a list of lists
        for (int row = 0; row < matrix.getRows(); row++) {
            List<String> rowData = new ArrayList<>();
            for (int col = 0; col < matrix.getCols(); col++) {
                rowData.add(String.valueOf(matrix.getValue(row, col)));
            }
            matrixData.add(rowData);
        }

        // Save the new matrix data to the file
        saveMatrixToFile(fileName, matrixData);
    }




    public static List<List<String>> loadMatrixFromFile(String filePath) {
        List<List<String>> matrixData = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            matrixData = reader.lines()
                    .map(line -> List.of(line.split(" ")))
                    .toList();
            System.out.println("Matrix data: \n" + matrixData);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return matrixData;
    }

    public static Matrix getMatrix(String key) {
        return matrices.get(key);
    }

    public static void setMatrix(String key, Matrix matrix) {
        matrices.put(key, matrix);
    }

    public static Matrix getCurrentMatrix() {
        return matrices.get("main_scene_matrix");
    }
}
