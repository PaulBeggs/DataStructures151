package matrix.gui;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import matrix.operators.MatrixElementaryOperations;
import matrix.operators.MatrixInputHandler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.text.DecimalFormat;

public class MatrixController implements DataManipulation {
    DecimalFormat decimalFormat = new DecimalFormat("#.##");
    @FXML
    Button generateButton, saveButton, operationButton;
    @FXML
    TextField sizeColsField, sizeRowsField, targetRow, sourceRow, multiplier, directions;
    @FXML
    ChoiceBox<Scenes> scenes;
    @FXML
    ChoiceBox<String> operations;
    private MatrixView matrixView;
    private MatrixElementaryOperations MEO;
    private Matrix matrix;
    private MatrixInputHandler MIH = new MatrixInputHandler();
    private int numCols, numRows;
    @FXML
    GridPane matrixGrid = new GridPane();
    private List<List<TextField>> matrixTextFields;
    private final String matrixFileName = "matrices/matrix_data.txt";

    @FXML
    private void initialize() {
        this.MEO = new MatrixElementaryOperations(matrix, matrixView);

        matrixTextFields = new ArrayList<>();

        operations.getItems().addAll("Swap Rows", "Multiply Rows", "Add Rows");
        operations.setValue("Swap Rows");

        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.MATRIX);

        // Setting up scene switching and UI text
        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.getMessage();
            }
        });

        directions.setEditable(false);
        directions.setText("Click 'generate' to produce a Matrix. The cells are editable; " +
                "use 'tab' to go through each cell and add an entry.");

        loadMatrixFromFile();
    }

    @FXML
    public void handleGenerateButton() {
        matrixGrid.getChildren().clear();
        numRows = Integer.parseInt(sizeRowsField.getText());
        numCols = Integer.parseInt(sizeColsField.getText());

        matrix = new Matrix(numRows, numCols);

//        System.out.println("Rows Text " + numRows);
//        System.out.println("Cols Text " + numCols);

        if (MIH.isPositiveIntValid(sizeColsField) && MIH.isPositiveIntValid(sizeRowsField)) {
            for (int row = 0; row < numRows; row++) {
                List<TextField> rowList = new ArrayList<>();
                for (int col = 0; col < numCols; col++) {
                    TextField cell = new TextField();
                    cell.setMinHeight(50);
                    cell.setMinWidth(50);
                    cell.setAlignment(Pos.CENTER);
                    cell.setEditable(true);

                    double randomValue = Math.floor(Math.random() * 10);
                    cell.setText(String.valueOf(randomValue));
                    matrix.setValue(row, col, randomValue);

                    cell.textProperty().addListener((observable, oldValue, newValue) -> {
                        if (!newValue.matches("\\d*(\\.\\d*)?")) {
                            cell.setText(newValue.replaceAll("[^\\d.]", ""));
                        }
                    });

                    matrixGrid.add(cell, col, row);
                    rowList.add(cell);
                }
                matrixTextFields.add(rowList);
            }
            System.out.println("Before Setting: \n" + matrix);
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
            System.out.println("After Setting: \n" + MatrixFileHandler.getMatrix("main_scene_matrix"));
        } else {
            sizeColsField.clear();
            sizeRowsField.clear();
            System.out.println("Invalid Row Indices.");
        }
    }
    @Override
    public void onChange() {
        saveMatrixToFile();
    }

    @Override
    public void loadMatrixFromFile() {
        List<List<String>> matrixData = MatrixFileHandler.loadMatrixFromFile(matrixFileName);
        if (matrixData != null) {
            if (!matrixData.isEmpty() && !matrixData.get(0).isEmpty()) {
                matrix = new Matrix(matrixData.size(), matrixData.get(0).size());
            } else {
                System.out.println("Error: matrixData is empty.");
            }
            System.out.println("2nd matrix data: \n" + matrixData);
            populateMatrixFromData();
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
        }
    }

    @Override
    public void populateMatrixFromData() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(matrixFileName));
            matrixGrid.getChildren().clear();
            numRows = 0;
            numCols = 0;
            // Read the file line by line to determine the dimensions
            String line;
            while ((line = br.readLine()) != null) {
                numRows++; // Increment row count for each line

                // Split the line to count columns
                String[] values = line.split("\\s+");
                numCols = Math.max(numCols, values.length);
            }

            System.out.println("Number of Rows: " + numRows);
            sizeRowsField.setText(Integer.toString(numRows));
            System.out.println("Number of Cols: " + numCols);
            sizeColsField.setText(Integer.toString(numCols));

            // Create a new Matrix with dimensions of Text File
            matrix = new Matrix(numRows, numCols);

            // Reset the BufferedReader to read from the file again
            br.close();
            br = new BufferedReader(new FileReader(matrixFileName));

            for (int row = 0; row < numRows; row++) {
                List<TextField> rowList = new ArrayList<>();
                line = br.readLine();
                String[] values = line.split("\\s+");

                for (int col = 0; col < numCols; col++) {
                    TextField cell = new TextField();
                    cell.setMinHeight(50);
                    cell.setMinWidth(50);
                    cell.setAlignment(Pos.CENTER);
                    cell.setEditable(true);

                    cell.setText(values[col]);
                    matrix.setValue(row, col, Double.parseDouble(values[col]));

                    cell.textProperty().addListener((observable, oldValue, newValue) -> {
                        if (!newValue.matches("\\d*(\\.\\d*)?")) {
                            cell.setText(newValue.replaceAll("[^\\d.]", ""));
                        }
                    });

                    matrixGrid.add(cell, col, row);
                    rowList.add(cell);
                }
                matrixTextFields.add(rowList);
            }

            System.out.println("Before Setting: \n" + matrix);
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
            System.out.println("After Setting: \n" + MatrixFileHandler.getMatrix("main_scene_matrix"));

        } catch (IOException e) {
            throw new RuntimeException(e);

        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @FXML
    public void saveMatrixToFile() {
        Matrix newMatrix = createMatrixFromTextFields();

        MatrixFileHandler.clearAndSaveMatrixToFile(matrixFileName, newMatrix);
    }

    @FXML
    private void performOperation() {
        String selectedOption = operations.getValue();

        if (MIH.isRowValid(targetRow, matrix.getRows()) && MIH.isRowValid(sourceRow, matrix.getRows())) {
            int targetRowIndex = Integer.parseInt(targetRow.getText()) - 1;
            int sourceRowIndex = Integer.parseInt(sourceRow.getText()) - 1;


            switch (selectedOption) {
                case "Swap Rows" -> {
                    MEO.swapRows(targetRowIndex, sourceRowIndex);
                    updateSwappedMatrixUI(targetRowIndex, sourceRowIndex);

                }
                case "Multiply Rows", "Add Rows" -> {
                    if (MIH.isDoubleValid(multiplier)) {
                        double rowMultiplier = Double.parseDouble(multiplier.getText());

                        if (selectedOption.equals("Multiply Rows")) {
                            MEO.multiplyRow(targetRowIndex, rowMultiplier);
                            updateMultipliedMatrixUI(targetRowIndex, rowMultiplier);

                        } else {
                            MEO.addRows(targetRowIndex, sourceRowIndex, rowMultiplier);
                            updateAddedMatrixUI(targetRowIndex, sourceRowIndex, rowMultiplier);
                        }

                    } else {
                        System.out.println("Invalid Multiplier. Please enter a valid double.");
                    }
                }
            }
        } else {
                System.out.println("At least one row is invalid. Fix it to proceed.");
        }
    }

    // To cut down on duplicated code and add some abstraction to the project:
    private enum MatrixOperation {
        SWAP,
        MULTIPLY,
        ADD
    }

    private void updateMatrixUI(int rowIndex, int numCols, MatrixOperation operation, int sourceRowIndex, double rowMultiplier) {
        try {
            for (int col = 0; col < numCols; col++) {
                double targetValue = Double.parseDouble(matrixTextFields.get(rowIndex).get(col).getText());
                double newValue;

                switch (operation) {
                    case SWAP -> {
                        newValue = Double.parseDouble(matrixTextFields.get(sourceRowIndex).get(col).getText());
                        matrixTextFields.get(sourceRowIndex).get(col).setText(String.valueOf(targetValue));
                    }
                    case MULTIPLY -> newValue = targetValue * rowMultiplier;
                    case ADD -> {
                        double sourceValue = Double.parseDouble(matrixTextFields.get(sourceRowIndex).get(col).getText());
                        newValue = targetValue + rowMultiplier * sourceValue;
                    }
                    default -> throw new IllegalArgumentException("Unsupported operation");
                }
                matrixTextFields.get(rowIndex).get(col).setText(String.valueOf((newValue)));
            }
        } catch (NumberFormatException e) {
            System.out.println("Error converting text to double: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    private void updateSwappedMatrixUI(int targetRowIndex, int sourceRowIndex) {
        double rowMultiplier = 0;
        updateMatrixUI(targetRowIndex, matrix.getCols(), MatrixOperation.SWAP, sourceRowIndex, rowMultiplier);
    }

    private void updateMultipliedMatrixUI(int targetRowIndex, double rowMultiplier) {
        int sourceRowIndex = 0;
        updateMatrixUI(targetRowIndex, matrix.getCols(), MatrixOperation.MULTIPLY, sourceRowIndex, rowMultiplier);
    }

    private void updateAddedMatrixUI(int targetRowIndex, int sourceRowIndex, double rowMultiplier) {
        updateMatrixUI(targetRowIndex, matrix.getCols(), MatrixOperation.ADD, sourceRowIndex, rowMultiplier);
    }

    @Override
    @FXML
    public void handleSaveButton() {
        List<List<String>> matrixData = new ArrayList<>();

        for (List<TextField> row : matrixTextFields) {
            List<String> rowData = row.stream().map(TextField::getText).collect(Collectors.toList());
            matrixData.add(rowData);
        }

        // Loading the SaveScene FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("resources/SaveScene.fxml"));
        Parent root;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        // Creating the SaveScene controller
        SaveController saveController = loader.getController();
        saveController.setMatrixTextFields(matrixTextFields);

        // Creating a new stage for the SaveScene
        Stage saveStage = new Stage();
        saveStage.setTitle("Save Matrix");
        saveStage.initModality(Modality.WINDOW_MODAL);
        saveStage.initOwner(MatrixApp.getPrimaryStage());
        saveController.setStage(saveStage);
        Scene saveScene = new Scene(root);
        saveStage.setScene(saveScene);
        saveStage.showAndWait();



        // Setting the SaveScene controller's stage
        saveController.setStage(saveStage);

        // After the SaveScene is closed, retrieve the file name from SaveSceneController
        String fileName = saveController.getFileName();

        if (fileName != null && !fileName.isEmpty()) {
            // Calling the method to save the matrix with the specified file name
            MatrixFileHandler.saveMatrixToFile("matrices/" + fileName + ".txt", matrixData);
        }
    }


    @Override
    @FXML
    public void handleLoadButton() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            String filePath = file.getAbsolutePath();
            List<List<String>> loadedMatrix = MatrixFileHandler.loadMatrixFromFile(filePath);

            // Updating UI (matrixTextFields) with the loaded matrix
            for (int i = 0; i < loadedMatrix.size(); i++) {
                List<String> rowValues = loadedMatrix.get(i);
                for (int j = 0; j < rowValues.size(); j++) {
                    String cellValue = rowValues.get(j);
                    matrixTextFields.get(i).get(j).setText(cellValue);
                }
            }
        }
    }
    private Matrix createMatrixFromTextFields() {
        Matrix newMatrix = new Matrix(numRows, numCols);

        int childIndex = 0; // Initialize the child index

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                if (childIndex < matrixGrid.getChildren().size()) {
                    TextField textField = (TextField) matrixGrid.getChildren().get(childIndex);
                    String text = textField.getText();

                    try {
                        double value = Double.parseDouble(text);
                        newMatrix.setValue(row, col, value);
                    } catch (NumberFormatException e) {
                        // Handle invalid input (non-numeric values)
                        // You can choose to ignore or provide feedback to the user
                    }

                    childIndex++; // Increment the child index
                }
            }
        }

        return newMatrix;
    }

}