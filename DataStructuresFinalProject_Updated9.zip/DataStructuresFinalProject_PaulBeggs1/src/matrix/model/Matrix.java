package matrix.model;

import java.util.Arrays;

public class Matrix implements MatrixOperations {

    private double[][] matrix;
    private Integer numCols;
    private Integer numRows;

    public Matrix(int numRows, int numCols) {
        this.numRows = numRows;
        this.numCols = numCols;
        matrix = new double[numRows][numCols];
    }

    public double getValue(int row, int col) {
        return matrix[row][col];
    }

    public void setValue(int row, int col, double value) {
        if (isValidRow(row) && isValidColumn(col)) {
            matrix[row][col] = value;
        } else {
            // Handle or log an error, depending on your requirements
            System.out.println("Invalid row or column index.");
        }
    }

    public void setMatrix(double[][] newMatrix) {
        for (int i = 0; i < numRows; i++) {
            System.arraycopy(newMatrix[i], 0, matrix[i], 0, numCols);
        }
    }

    @Override
    public double[][] getMatrix() {
        return matrix;
    }

    @Override
    public int getRows() {
        return matrix.length;
    }

    @Override
    public int getCols() {
        return matrix[0].length;
    }

    @Override
    public boolean isValidRow(int row) {
        return row >= 0 && row < numRows;
    }

    private boolean isValidColumn(int col) {
        return col >= 0 && col < numCols;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        for (double[] row : matrix) {
            result.append(Arrays.toString(row)).append("\n");
        }
        return result.toString();
    }
}
