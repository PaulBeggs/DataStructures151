package matrix.gui;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import matrix.operators.MatrixElementaryOperations;
import matrix.operators.MatrixInputHandler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.text.DecimalFormat;

public class MatrixController implements DataManipulation {
    DecimalFormat decimalFormat = new DecimalFormat("#.##");
    @FXML
    Button generateButton, saveButton, operationButton;
    @FXML
    TextField sizeColsField, sizeRowsField, targetRow, sourceRow, multiplier, directions;
    @FXML
    ChoiceBox<Scenes> scenes;
    @FXML
    ChoiceBox<String> operations;
    private MatrixView matrixView;
    private MatrixElementaryOperations MEO;
    private Matrix matrix;
    private MatrixInputHandler MIH = new MatrixInputHandler();
    private int numCols, numRows;
    @FXML
    GridPane matrixGrid = new GridPane();
    private List<List<TextField>> matrixTextFields;
    private final String matrixFileName = "matrices/matrix_data.txt";

    @FXML
    private void initialize() {
        this.MEO = new MatrixElementaryOperations(matrix, matrixView);

        matrixTextFields = new ArrayList<>();

        operations.getItems().addAll("Swap Rows", "Multiply Rows", "Add Rows");
        operations.setValue("Swap Rows");

        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.MATRIX);

        // Setting up scene switching and UI text
        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.getMessage();
            }
        });

        directions.setEditable(false);
        directions.setText("Click 'generate' to produce a Matrix. The cells are editable; " +
                "use 'tab' to go through each cell and add an entry.");

        loadFromFile();
    }

    @FXML
    public void handleGenerateButton() {
        matrixGrid.getChildren().clear();
        numRows = Integer.parseInt(sizeRowsField.getText());
        numCols = Integer.parseInt(sizeColsField.getText());

        this.matrix = new Matrix(numRows, numCols);

        this.matrixTextFields = new ArrayList<>();

//        System.out.println("Rows Text " + numRows);
//        System.out.println("Cols Text " + numCols);

        if (MIH.isPositiveIntValid(sizeColsField) && MIH.isPositiveIntValid(sizeRowsField)) {
            for (int row = 0; row < numRows; row++) {
                List<TextField> rowList = new ArrayList<>();
                for (int col = 0; col < numCols; col++) {
                    TextField cell = new TextField();
                    cell.setMinHeight(50);
                    cell.setMinWidth(50);
                    cell.setAlignment(Pos.CENTER);
                    cell.setEditable(true);

                    double randomValue = Math.floor(Math.random() * 10);
                    cell.setText(String.valueOf(randomValue));
                    matrix.setValue(row, col, randomValue);

                    cell.textProperty().addListener((observable, oldValue, newValue) -> {
                        if (!newValue.matches("\\d*(\\.\\d*)?")) {
                            cell.setText(newValue.replaceAll("[^\\d.]", ""));
                        }
                    });

                    matrixGrid.add(cell, col, row);
                    rowList.add(cell);
                }
                matrixTextFields.add(rowList);
            }
            System.out.println("Before Setting: \n" + matrix);
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
            System.out.println("After Setting: \n" + MatrixFileHandler.getMatrix("main_scene_matrix"));
        } else {
            sizeColsField.clear();
            sizeRowsField.clear();
            System.out.println("Invalid Row Indices.");
        }
    }

    @Override
    public void loadFromFile() {
        List<List<String>> matrixData = MatrixFileHandler.loadMatrixFromFile(matrixFileName);
        if (matrixData != null) {
            if (!matrixData.isEmpty() && !matrixData.get(0).isEmpty()) {
                this.matrix = new Matrix(matrixData.size(), matrixData.get(0).size());
            } else {
                System.out.println("Error: matrixData is empty.");
            }
            System.out.println("2nd matrix data: \n" + matrixData);
            populateMatrixFromData(matrixFileName);
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
        }
    }

    @Override
    public void populateMatrixFromData(String filePath) {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            clearMatrix();
            determineMatrixDimensions(br, filePath);

            createMatrixFromFile(filePath);

            printMatrixDetails();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void clearMatrix() {
        matrixTextFields = new ArrayList<>();
        matrixGrid.getChildren().clear();
    }

    private void determineMatrixDimensions(BufferedReader br, String filePath) throws IOException {
        numRows = 0;
        numCols = 0;

        while (br.readLine() != null) {
            numRows++;
        }

        br.close();
        br = new BufferedReader(new FileReader(filePath));

        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split("\\s+");
            numCols = Math.max(numCols, values.length);
        }

        updateMatrixSizeFields();
    }

    private void updateMatrixSizeFields() {
        System.out.println("Number of Rows: " + numRows);
        sizeRowsField.setText(Integer.toString(numRows));
        System.out.println("Number of Cols: " + numCols);
        sizeColsField.setText(Integer.toString(numCols));
    }

    private void createMatrixFromFile(String filePath) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            matrix = new Matrix(numRows, numCols);

            for (int row = 0; row < numRows; row++) {
                List<TextField> rowList = createAndAddRow(br.readLine(), row);
                matrixTextFields.add(rowList);
            }

            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
        }
    }

    private List<TextField> createAndAddRow(String line, int row) {
        List<TextField> rowList = new ArrayList<>();
        String[] values = line.split("\\s+");

        for (int col = 0; col < numCols; col++) {
            TextField cell = createAndConfigureCell(values[col], row, col);
            matrixGrid.add(cell, col, row);
            rowList.add(cell);
        }

        return rowList;
    }

    private void printMatrixDetails() {
        System.out.println("Before Setting: \n" + matrix);
        System.out.println("After Setting: \n" + MatrixFileHandler.getMatrix("main_scene_matrix"));
    }


    private TextField createAndConfigureCell(String value, int row, int col) {
        TextField cell = new TextField();
        cell.setMinHeight(50);
        cell.setMinWidth(50);
        cell.setAlignment(Pos.CENTER);
        cell.setEditable(true);

        cell.setText(value);
        this.matrix.setValue(row, col, Double.parseDouble(value));

        cell.textProperty().addListener((observable, oldValue, newValue) -> {
            if (!newValue.matches("\\d*(\\.\\d*)?")) {
                cell.setText(newValue.replaceAll("[^\\d.]", ""));
            }
        });

        return cell;
    }


    @FXML
    public void saveToFile() {

        // Update the matrix with the modified values from the UI
        updateMatrixFromUI();

        // Create matrixData for saving
        List<List<String>> matrixData = new ArrayList<>();
        for (int row = 0; row < matrix.getRows(); row++) {
            List<String> rowData = new ArrayList<>();
            for (int col = 0; col < matrix.getCols(); col++) {
                rowData.add(String.valueOf(matrix.getValue(row, col)));
            }
            matrixData.add(rowData);
        }

        // Save the matrix directly to the file
        MatrixFileHandler.saveMatrixToFile(matrixFileName, matrixData);
        System.out.println("Matrix saved to " + matrixFileName);
        System.out.println(matrixData);
    }

    private void updateMatrixFromUI() {
        for (int row = 0; row < matrixTextFields.size(); row++) {
            for (int col = 0; col < matrixTextFields.get(row).size(); col++) {
                String textValue = matrixTextFields.get(row).get(col).getText();
                double numericValue = Double.parseDouble(textValue);
                matrix.setValue(row, col, numericValue);
            }
        }
    }


    public void setMatrixTextFields(List<List<TextField>> matrixTextFields) {
        this.matrixTextFields = matrixTextFields;
    }

    @FXML
    private void performOperation() {
        String selectedOption = operations.getValue();

        if (MIH.isRowValid(targetRow, matrix.getRows()) && MIH.isRowValid(sourceRow, matrix.getRows())) {
            int targetRowIndex = Integer.parseInt(targetRow.getText()) - 1;
            int sourceRowIndex = Integer.parseInt(sourceRow.getText()) - 1;


            switch (selectedOption) {
                case "Swap Rows" -> {
                    MEO.swapRows(targetRowIndex, sourceRowIndex);
                    updateSwappedMatrixUI(targetRowIndex, sourceRowIndex);

                }
                case "Multiply Rows", "Add Rows" -> {
                    if (MIH.isDoubleValid(multiplier)) {
                        double rowMultiplier = Double.parseDouble(multiplier.getText());

                        if (selectedOption.equals("Multiply Rows")) {
                            MEO.multiplyRow(targetRowIndex, rowMultiplier);
                            updateMultipliedMatrixUI(targetRowIndex, rowMultiplier);

                        } else {
                            MEO.addRows(targetRowIndex, sourceRowIndex, rowMultiplier);
                            updateAddedMatrixUI(targetRowIndex, sourceRowIndex, rowMultiplier);
                        }

                    } else {
                        System.out.println("Invalid Multiplier. Please enter a valid double.");
                    }
                }
            }
        } else {
                System.out.println("At least one row is invalid. Fix it to proceed.");
        }
    }

    // To cut down on duplicated code and add some abstraction to the project:
    private enum MatrixOperation {
        SWAP,
        MULTIPLY,
        ADD
    }

    private void updateMatrixUI(int rowIndex, int numCols, MatrixOperation operation, int sourceRowIndex, double rowMultiplier) {
        try {
            for (int col = 0; col < numCols; col++) {
                double targetValue = Double.parseDouble(matrixTextFields.get(rowIndex).get(col).getText());
                double newValue;

                switch (operation) {
                    case SWAP -> {
                        newValue = Double.parseDouble(matrixTextFields.get(sourceRowIndex).get(col).getText());
                        matrixTextFields.get(sourceRowIndex).get(col).setText(String.valueOf(targetValue));
                    }
                    case MULTIPLY -> newValue = targetValue * rowMultiplier;
                    case ADD -> {
                        double sourceValue = Double.parseDouble(matrixTextFields.get(sourceRowIndex).get(col).getText());
                        newValue = targetValue + rowMultiplier * sourceValue;
                    }
                    default -> throw new IllegalArgumentException("Unsupported operation");
                }
                matrixTextFields.get(rowIndex).get(col).setText(String.valueOf((newValue)));
            }
        } catch (NumberFormatException e) {
            System.out.println("Error converting text to double: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    private void updateSwappedMatrixUI(int targetRowIndex, int sourceRowIndex) {
        double rowMultiplier = 0;
        updateMatrixUI(targetRowIndex, matrix.getCols(), MatrixOperation.SWAP, sourceRowIndex, rowMultiplier);
        saveToFile();
    }

    private void updateMultipliedMatrixUI(int targetRowIndex, double rowMultiplier) {
        int sourceRowIndex = 0;
        updateMatrixUI(targetRowIndex, matrix.getCols(), MatrixOperation.MULTIPLY, sourceRowIndex, rowMultiplier);
        saveToFile();
    }

    private void updateAddedMatrixUI(int targetRowIndex, int sourceRowIndex, double rowMultiplier) {
        updateMatrixUI(targetRowIndex, matrix.getCols(), MatrixOperation.ADD, sourceRowIndex, rowMultiplier);
        saveToFile();
    }

    @Override
    @FXML
    public void handleSaveButton() {
        Stage saveStage = new Stage();
        saveStage.setTitle("Save Matrix");
        saveStage.initModality(Modality.WINDOW_MODAL);
        saveStage.initOwner(MatrixApp.getPrimaryStage());

        FXMLLoader loader = new FXMLLoader(getClass().getResource("resources/SaveScene.fxml"));
        Parent root;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        SaveController saveController = loader.getController();
        saveController.setMatrixTextFields(matrixTextFields);
        saveController.setStage(saveStage);

        Scene saveScene = new Scene(root);
        saveStage.setScene(saveScene);
        saveStage.showAndWait();
    }

    @FXML
    public void handleLoadButton() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            String filePath = file.getAbsolutePath();
            populateMatrixFromData(filePath);
        }
    }
}