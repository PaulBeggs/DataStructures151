package matrix.gui;

public interface DataManipulation {
    void handleSaveButton();
    void loadFromFile();
    void populateMatrixFromData(String fileName);
    void saveToFile();
}
