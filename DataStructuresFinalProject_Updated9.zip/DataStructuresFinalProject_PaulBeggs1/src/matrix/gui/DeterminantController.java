package matrix.gui;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;
import matrix.operators.MatrixDeterminantOperations;

import java.io.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DeterminantController implements DataManipulation {

    DecimalFormat decimalFormat = new DecimalFormat("#.##");
    @FXML
    Button saveButton;
    @FXML
    TextField targetRow, sourceRow, determinantValue;
    @FXML
    GridPane matrixGrid = new GridPane();
    @FXML
    ChoiceBox<Scenes> scenes;
    private int numRows, numCols;
    private Matrix matrix;
    private double determinant;
    private final String matrixFileName = "matrices/matrix_data.txt";


    @FXML
    private void initialize() {
        matrix = MatrixFileHandler.getMatrix("main_scene_matrix");

        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.DETERMINANT);

        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.getMessage();
            }
        });

        loadFromFile();
    }

    @FXML
    public void handleDeterminantFunctionality() {
        Matrix matrix = MatrixFileHandler.getMatrix("main_scene_matrix");
        System.out.println("2nd Matrix: \n" + matrix + "\n");

        if (matrix != null) {
            MatrixDeterminantOperations determinantOperations = new MatrixDeterminantOperations(matrix);
            determinant = determinantOperations.calculateDeterminant();
            determinantValue.setText(Double.toString(Double.parseDouble(decimalFormat.format(determinant))));
            System.out.println("Determinant: " + decimalFormat.format(determinant));

            saveToFile();
        } else {
            System.out.println("Matrix not found. Generate a matrix first.");
        }
    }

    @Override
    @FXML
    public void handleSaveButton() {
        Stage saveStage = new Stage();
        saveStage.setTitle("Save Determinant");
        saveStage.initModality(Modality.WINDOW_MODAL);
        saveStage.initOwner(MatrixApp.getPrimaryStage());

        FXMLLoader loader = new FXMLLoader(getClass().getResource("resources/SaveScene.fxml"));
        Parent root;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        SaveController saveController = loader.getController();
        saveController.setDeterminantValue(Double.parseDouble(decimalFormat.format(determinant)));
        saveController.setStage(saveStage);

        Scene saveScene = new Scene(root);
        saveStage.setScene(saveScene);
        saveStage.showAndWait();
    }



    @Override
    public void loadFromFile() {
        List<List<String>> matrixData = MatrixFileHandler.loadMatrixFromFile(matrixFileName);
        if (matrixData != null) {
            if (!matrixData.isEmpty() && !matrixData.get(0).isEmpty()) {
                matrix = new Matrix(matrixData.size(), matrixData.get(0).size());
            } else {
                System.out.println("Error: matrixData is empty.");
            }
            System.out.println("2nd matrix data: \n" + matrixData);
            populateMatrixFromData(matrixFileName);
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
        }
    }

    @Override
    public void populateMatrixFromData(String fileName) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(matrixFileName));
            matrixGrid.getChildren().clear();
            numRows = 0;
            numCols = 0;

                String line;
                while ((line = br.readLine()) != null) {
                    numRows++;

                    String[] values = line.split("\\s+");
                    numCols = Math.max(numCols, values.length);
                }

                // Create a new Matrix with dimensions of Text File
                matrix = new Matrix(numRows, numCols);

                // Reset the BufferedReader to read from the file again
                br.close();
                br = new BufferedReader(new FileReader(matrixFileName));

                for (int row = 0; row < numRows; row++) {
                    List<TextField> rowList = new ArrayList<>();
                    line = br.readLine();
                    String[] values = line.split("\\s+");

                    for (int col = 0; col < numCols; col++) {
                        TextField cell = new TextField();
                        cell.setMinHeight(50);
                        cell.setMinWidth(50);
                        cell.setAlignment(Pos.CENTER);
                        cell.setEditable(false);

                        cell.setText(values[col]);
                        matrix.setValue(row, col, Double.parseDouble(values[col]));

                        cell.textProperty().addListener((observable, oldValue, newValue) -> {
                            if (!newValue.matches("\\d*(\\.\\d*)?")) {
                                cell.setText(newValue.replaceAll("[^\\d.]", ""));
                            }
                        });

                        matrixGrid.add(cell, col, row);
                        rowList.add(cell);
                    }
                }

                System.out.println("Before Setting: \n" + matrix);
                MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
                System.out.println("After Setting: \n" + MatrixFileHandler.getMatrix("main_scene_matrix"));

        } catch (IOException e) {
            throw new RuntimeException(e);

        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void saveToFile() {
        String filePath = "determinants/determinant_result.txt";

        try (PrintWriter writer = new PrintWriter(filePath)) {

            writer.println("Determinant: \n" + determinant);
            System.out.println("Determinant saved to file: " + filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}


