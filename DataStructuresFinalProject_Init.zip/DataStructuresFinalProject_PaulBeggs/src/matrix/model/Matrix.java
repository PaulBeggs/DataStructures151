package matrix.model;


public class Matrix {
    private double[][] matrix;


    public Matrix(int numRows, int numCols) {
        matrix = new double[numRows][numCols];
    }
    /*
     In "getMatrixValues" I have done research about the possibility of using a Singleton Class
       to store the data in a way that can be accessed from each Controller.
         (see: https://dev.to/devtony101/javafx-3-ways-of-passing-information-between-scenes-1bm8)
     However, this is very confusing to me, and I do not fully comprehend a basis
       for implementing this.
     */
    public void getMatrixValues() {

    }

    public int getRows() {
        return matrix.length;
    }

    public int getCols() {
        return matrix[0].length;
    }

    public void swapRows(int row1, int row2) {
        if (isValidRow(row1) && isValidRow(row2)) {
            double[] temp = matrix[row1];
            matrix[row1] = matrix[row2];
            matrix[row2] = temp;
        }
    }

    public void multiplyRow(int row, double multiplier) {
        if (isValidRow(row)) {
            for (int col = 0; col < getCols(); col++) {
                matrix[row][col] *= multiplier;
            }
        }
    }

    public void addRows(int sourceRow, int targetRow, double multiplier) {
        if (isValidRow(sourceRow) && isValidRow(targetRow)) {

            for (int col = 0; col < getCols(); col++) {
                matrix[targetRow][col] += multiplier * matrix[sourceRow][col];
            }
        }
    }

    private boolean isValidRow(int row) {
        return row >= 0 && row < getRows();
    }
}