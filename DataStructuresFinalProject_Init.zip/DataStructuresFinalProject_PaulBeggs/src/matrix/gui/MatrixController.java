package matrix.gui;

import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;
import matrix.model.Matrix;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.io.IOException;

public class MatrixController {
    @FXML
    Button generateButton;
    @FXML
    TextField sizeColsField;
    @FXML
    TextField sizeRowsField;
    @FXML
    ChoiceBox<Scenes> operations;
    @FXML
    Button switchButton;

    /*
     Given that computationalMatrix works off the Matrix class
       within the model, it would be best to have all
       functionality go through this model to cut down on the
       abstraction of the project.
     */

    public Matrix computationalMatrix;

    /*
     And how to save the user input for the GridPane matrix into the
       computationalMatrix variable where it can be used...
     I have no idea.
     */
    @FXML
    GridPane matrix = new GridPane();
    @FXML
    TextField directions;

    @FXML
    private void initialize() {
        /*
         "operations" is the choice box in which the user can choose which
           scene they want to go to.
         This is later accessed in the "handleSwitchButton(event)" that is
           available in every controller.
         This, and the message within "handleSwitchButton(event)" are
           duplicates.
         */
        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.MATRIX);
        /*
         To cut down on the multifaceted nature of this project, (and to limit
           some abstraction), the columns and rows have been disabled.
         */
        sizeColsField.setEditable(false);
        sizeRowsField.setEditable(false);

        directions.setEditable(false);
        directions.setText("Click 'generate' to produce a Matrix. The cells are editable;" +
                " use 'tab' to go through each cell and add an entry.");
    }

    @FXML
    public void handleSwitchButton(ActionEvent event) {
        /*
         Once the operation is picked, the "switchButton" can be used to switch between scenes.
         (With "Scenes" being an enum that stores all the different scenes available.)
         */
        Scenes selectedScene = operations.getValue();
        try {
            selectedScene.switchScene(event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void handleGenerateButton() {
        int numRows = Integer.parseInt(sizeRowsField.getText());
        int numCols = Integer.parseInt(sizeColsField.getText());

        /*
         I want to use this "computationalMatrix" in a way that is
           accessible from the other controllers.
         If I can find a way to use this computationalMatrix in each
           controller such that every row addition, or row swap
           is accounted for, then in this updated matrix GUI, it can
           display each change that has been made!
         */
        computationalMatrix = new Matrix(numRows, numCols);

        /*
         This generates a new matrix with all entries set to 0.
           (see: https://gist.github.com/ollkostin/6174f18cb05b92ca191492605cd39daa)
         Maybe, it would be best to have some way of implementing this
           among the other controllers such that it does not set the
           text to 0, but it sets the text based on the previous
           entries within the grid pane?
        */
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                TextField tf = new TextField();
                tf.setPrefHeight(100);
                tf.setPrefWidth(150);
                tf.setAlignment(Pos.CENTER);
                tf.setEditable(true);
                tf.setText("0");
                matrix.add(tf, col, row);
            }
        }
    }
    /*
     I know that a function like "updateMatrixUI" must be useful in the
       implementation of this.
     I also know that it would probably be best to have one of these in
       each controller.
     Perhaps the edition of another enum that systematically updates the
       matrix based on what the inputs in the other controllers would
       be the best bet?
     */
    public void updateMatrixUI() {

    }
}
