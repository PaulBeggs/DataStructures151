package matrix.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;

public enum Scenes {
    /*
     This enum is important because it allows brevity within the other classes.
     The "toString" method is simply there to accompany the choices within the box.
     */
    ADDITION {
        @Override
        public String toString() {
            return "Addition";
        }

        @Override
        public void switchScene(ActionEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("addScene.fxml"));
            switchToScene(event, root);


        }
    },
    MULTIPLICATION {
        @Override
        public String toString() {
            return "Multiplication";
        }

        @Override
        public void switchScene(ActionEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("multiplicationScene.fxml"));
            switchToScene(event, root);
        }
    },
    ROW {
        @Override
        public String toString() {
            return "Row";
        }

        @Override
        public void switchScene(ActionEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("rowScene.fxml"));
            switchToScene(event, root);
        }
    },
    MATRIX {
        @Override
        public String toString() {
            return "Updated Matrix";
        }

        @Override
        public void switchScene(ActionEvent event) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("matrixGUI.fxml"));
            switchToScene(event, root);
        }
    };

    private Stage stage;
    private Scene scene;

    public abstract void switchScene(ActionEvent event) throws IOException;

    protected void switchToScene(ActionEvent event, Parent root) {
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
}
