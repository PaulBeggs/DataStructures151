package matrix.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class RowSwapController {
    @FXML
    TextField rowOne;
    @FXML
    TextField rowTwo;
    @FXML
    Button switchButton;
    @FXML
    ChoiceBox<Scenes> operations;
    @FXML
    private void initialize() {
        /*
         "operations" is the choice box in which the user can choose which
           scene they want to go to.
         This is later accessed in the "handleSwitchButton(event)" that is
           available in every controller.
         This, and the message within "handleSwitchButton(event)" are
           duplicates.
         */
        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.ROW);
    }
    @FXML
    public void handleSwitchButton(ActionEvent event) {
        /*
         Once the operation is picked, the "switchButton" can be used to switch between scenes.
         (With "Scenes" being an enum that stores all the different scenes available.)
         */
        Scenes selectedScene = operations.getValue();
        try {
            selectedScene.switchScene(event);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /*
     In the below method, I understand a way to implement this using the Matrix class
       within the model folder, but I do not understand how I would implement this
       with something such as a grid pane matrix model.
     (DUPLICATE 3/3)
     */
    @FXML
    private void handleRowSwapFunctionality() {

    }
}
