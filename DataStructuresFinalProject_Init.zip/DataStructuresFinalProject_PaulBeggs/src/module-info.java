module DataStructuresProject2_PaulBeggs {
    requires javafx.fxml;
    requires javafx.controls;
    exports matrix.gui;
    exports matrix.model;
    opens matrix.gui;
    opens matrix.model;
}