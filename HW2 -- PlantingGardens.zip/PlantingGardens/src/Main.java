public class Main {
    public static void main(String[] args) {
        Garden g = new Garden(5, "garlic");

        g.plant(0);

        System.out.println("Should return: 'Needs Water!'");
        System.out.println("Harvesting plot 0: " + g.harvest(0));
        System.out.println("\n");

        g.plant(2);;
        g.water();

        System.out.println("Should return: 'garlic'");
        System.out.println("Harvesting plot 2: " + g.harvest(2));
        System.out.println("\n");

        System.out.println("Should return: 'Nothing but Dirt...'");
        System.out.println("Harvesting plot 4: " + g.harvest(4));
    }
}