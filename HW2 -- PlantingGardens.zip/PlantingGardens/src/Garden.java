import java.util.Arrays;

public class Garden {
    private Dirt[] plots;
    private String cropType;

    public Garden(int numPlots, String cropType) {
        this.cropType = cropType;
        plots = new Dirt[numPlots];
        for (int i = 0; i < plots.length; i++) {
            plots[i] = Dirt.EMPTY;
        }
    }

    public void plant(int plotNum) {
        if (plotNum >= 0 && plotNum < plots.length && plots[plotNum] == Dirt.EMPTY) {
            plots[plotNum] = Dirt.SEED;
        }
    }

    public void water() {
        for (int i = 0; i < plots.length; i++) {
            if (plots[i] == Dirt.SEED) {
                plots[i] = Dirt.PLANT;
            }
        }
    }

    public String harvest(int plotNum) {
        if (plotNum >= 0 && plotNum < plots.length) {
            if (plots[plotNum] == Dirt.PLANT) {
                plots[plotNum] = Dirt.EMPTY;
                return cropType;
            } else if (plots[plotNum] == Dirt.SEED) {
                return "Needs Water!";
            }
        }
        return "Nothing but Dirt...";
    }
}