public enum Dirt {
    EMPTY,
    SEED,
    PLANT;
}
