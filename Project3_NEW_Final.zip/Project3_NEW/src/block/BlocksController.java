package block;

import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;

public class BlocksController {

	@FXML
	private AnchorPane pane;
	@FXML
	private TextField timer;
	@FXML
	private TextField nRectangles;
	@FXML
	private TextField scoreField;
	private int score;

	private ArrayList<Block> rectangles;
	private ArrayList<BlocksView> bvs;

	private Movement clock;
	private boolean onOff;
	private long startTime;

	private class Movement extends AnimationTimer {


		private long FRAMES_PER_SEC = 500000L;
		private long INTERVAL = 1000000000L / FRAMES_PER_SEC;

		private long last = 0;
		private double length = 17;
		private double dr = 0.1;
		private ArrayList<Block> bs;

		public void setBlocks(ArrayList<Block> bs) {
			this.bs = bs;
		}
		private void moveBlocks() {
			for (Block b : bs) {
				b.move();
				b.setDimensions(length * 2);
			}
		}

		@Override
		public void handle(long now) {
			if (now - last > INTERVAL) {
				moveBlocks();
				updateViews();
				last = now;
			}
			length += dr;
			if (length > 50 || length < 15) {
				dr *= -1;
			}

			score = rectangles.size();
			updateScore();
			if (onOff) {
				if (score != 0) {
					timer.setText(elapsedTime(now - startTime));
				} else {
					stop();
				}
			}
		}
	}

	@FXML
	public void initialize() {
		timer.setEditable(false);
		rectangles = new ArrayList<Block>();
		bvs = new ArrayList<BlocksView>();
		onOff = false;
		score = 0;

		nRectangles.textProperty().addListener(new ChangeListener<String>() {
			@Override
			public void changed(ObservableValue<? extends String> observableValue, String s, String t1) {
				resetRectangles();
			}
		});

		clock = new Movement();
		clock.setBlocks(rectangles);
	}

	@FXML
	public void start() {
		if (!onOff) {
			startTime = System.nanoTime();
			clock.start();
			onOff = true;
		}
	}
	@FXML
	public void stop() {
		clock.stop();
		onOff = false;
	}
	@FXML
	public void reset() {
		stop();
		resetScore();
		startTime = System.nanoTime();
		timer.clear();
		timer.setText("00:00:00");
		onOff = false;
		resetRectangles();
	}

	private void resetRectangles() {
        pane.getChildren().clear();

        rectangles.clear();
        bvs.clear();

        int numRectangles = 0;
        try {
            numRectangles = Integer.parseInt(nRectangles.getText());
        } catch (NumberFormatException ignored) {}

        for (int i = 0; i < numRectangles; i++) {
            makeBlock();
        }
    }

	@FXML
	private void makeBlock() {
		Block b = new Block(17);
		rectangles.add(b);

		BlocksView bv = new BlocksView(b, this::removeBlock);
		bvs.add(bv);
		pane.getChildren().add(bv);

		updateViews();
	}

	private void removeBlock(BlocksView bv) {
		if (onOff) {
			pane.getChildren().remove(bv);
			rectangles.remove(bv.getBlock());
			bvs.remove(bv);
			updateScore();
		}
	}

	private void resetScore() {
		scoreField.clear();
		scoreField.setPromptText("Remaining Boxes");

	}

	private void updateScore() {
		scoreField.setText(String.valueOf(score));
	}

	private void updateViews() {
		for (BlocksView bv : bvs) {
			bv.update();
		}
	}

	private String elapsedTime(long time) {
		long minutes = time / 60000000000L;
		long seconds = (time % 60000000000L) / 1000000000L;
		long milliseconds = (time % 1000000000L) / 1000000L;

		return String.format("%02d:%02d:%02d", minutes, seconds, milliseconds);
	}
}
