package block;

public class Block {

	private double x;
	private double y;
	private double dx;
	private double dy;
	private double length;
	private boolean canMove;

	public Block(double length) {
		this.length = length;

		x = length + 100 - (2 * length);
		y = length + 200 - (2 * length);

		dx = Math.random() * 6 - 1.0;
		dy = Math.random() * 6 - 1.0;

		canMove = true;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getLength() {
		return this.length;
	}
	public void toggleMovement() { canMove = !canMove; }
	public void move() {
		if (canMove) {
			x += dx;
			double overX = Math.max(0, x + length - 200);
			overX = Math.max(overX, length - x);
			if (overX > 0) {
				dx *= -1.0;
				x += Math.signum(dx) * overX;
			}

			y += dy;
			double overY = Math.max(0, y + length - 200);
			overY = Math.max(overY, length - y);
			if (overY > 0) {
				dy *= -1.0;
				y += Math.signum(dy) * overY;
			}
		}
	}
	public void setDimensions(double length) {
		this.length = length / 2;
	}
}
