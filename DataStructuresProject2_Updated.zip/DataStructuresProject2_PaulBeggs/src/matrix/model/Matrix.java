package matrix.model;


public class Matrix {
    private double[][] matrix;


    public Matrix(int numRows, int numCols) {
        matrix = new double[numRows][numCols];
    }

    public int getRows() {
        return matrix.length;
    }

    public int getCols() {
        return matrix[0].length;
    }

    public void swapRows(int row1, int row2) {
        if (isValidRow(row1) && isValidRow(row2)) {
            double[] temp = matrix[row1];
            matrix[row1] = matrix[row2];
            matrix[row2] = temp;
        }
    }

    public boolean isValidRow(int row) {
        return row >= 0 && row < getRows();
    }
}
