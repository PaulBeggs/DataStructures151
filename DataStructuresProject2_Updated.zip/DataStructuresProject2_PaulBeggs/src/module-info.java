module DataStructuresProject2.PaulBeggs {
    requires javafx.controls;
    requires javafx.fxml;
    exports matrix.gui;
    exports matrix.model;
    opens matrix.gui;
    opens matrix.model;

}