package matrix.operators;

public interface RREF {

    boolean isValidRow(int row);
    boolean isValidCol(int col);
}
