package matrix.model;

public class Matrix implements MatrixOperations {

    private double[][] matrix;
    private int numCols;
    private int numRows;

    public Matrix(int numRows, int numCols) {
        this.matrix = new double[numRows][numCols];
    }

    @Override
    public double[][] getMatrix() {
        return matrix;
    }

    @Override
    public int getRows() {
        return matrix.length;
    }

    @Override
    public int getCols() {
        if (getRows() > 0) {
            return matrix[0].length;
        } else {
            return 0;
        }
    }

    @Override
    public boolean isValidRow(int row) {
        return row >= 0 && row < numRows;
    }

    private boolean isValidColumn(int col) {
        return col >= 0 && col < numCols;
    }
}
