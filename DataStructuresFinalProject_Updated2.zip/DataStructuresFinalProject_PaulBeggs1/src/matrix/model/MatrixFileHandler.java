package matrix.model;

import java.io.*;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class MatrixFileHandler {

    public static void saveMatrixToFile(String fileName, List<List<Double>> matrixData) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false))) {
            for (List<Double> row : matrixData) {
                String line = row.stream()
                        .map(Object::toString)
                        .collect(Collectors.joining(" "));
                writer.write(line);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<List<Double>> loadMatrixFromFile(String filePath) {
        List<List<Double>> matrixData = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            matrixData = reader.lines()
                    .map(line -> Arrays.stream(line.split(" "))
                            .map(Double::parseDouble)
                            .collect(Collectors.toList()))
                    .toList();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return matrixData;
    }
}

