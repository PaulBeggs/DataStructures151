package matrix.model;

import javafx.scene.control.TextField;
import matrix.operators.MatrixInputHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MatrixView {
    private Matrix matrix;
    private List<List<TextField>> matrixTextFields;
    private List<List<Double>> loadedMatrix;


    public MatrixView(Matrix matrix, List<List<TextField>> matrixTextFields, List<List<Double>> loadedMatrix) {
        this.matrix = matrix;
        this.matrixTextFields = matrixTextFields;
        this.loadedMatrix = loadedMatrix;
    }

    public Matrix getMatrix() {
        return matrix;
    }

    public List<List<TextField>> getMatrixTextFields() {
        return matrixTextFields;
    }



    public void saveMatrixData() {
        if (matrixTextFields != null) {
            List<List<String>> matrixData = new ArrayList<>();

            for (List<TextField> row : matrixTextFields) {
                List<String> rowData = row.stream().map(TextField::getText).collect(Collectors.toList());
                matrixData.add(rowData);
            }

            String fileName = "computational matrix";

            // Calling the method to save the matrix with the specified file name
            MatrixFileHandler.saveMatrixToFile("matrices/" + fileName + ".txt", matrixData);
        }
    }
    public void loadMatrixData(List<List<Double>> matrixData) {
        // Updating UI with loaded matrixData
        for (int i = 0; i < matrixData.size(); i++) {
            List<Double> rowValues = matrixData.get(i);
            for (int j = 0; j < rowValues.size(); j++) {
                double cellValue = rowValues.get(j);
                matrixTextFields.get(i).get(j).setText(String.valueOf(cellValue));
            }
        }
    }

    public void update() {
        if (matrix != null && matrixTextFields != null) {
            double[][] matrixValues = matrix.getMatrix();

            // Update UI (matrixTextFields)
            for (int i = 0; i < matrixTextFields.size(); i++) {
                for (int j = 0; j < matrixTextFields.get(i).size(); j++) {
                    matrixTextFields.get(i).get(j).setText(String.valueOf(matrixValues[i][j]));
                }
            }

            // Update loaded matrix (loadedMatrix)
            loadedMatrix.clear();  // Clear existing data

            for (int i = 0; i < matrixValues.length; i++) {
                List<Double> rowValues = new ArrayList<>();

                for (int j = 0; j < matrixValues[i].length; j++) {
                    rowValues.add(matrixValues[i][j]);
                }

                loadedMatrix.add(rowValues);
            }
        }
    }

}