package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class RREFController implements Data{
    @FXML
    TextField rowOne;
    @FXML
    TextField rowTwo;
    @FXML
    Button switchButton;
    @FXML
    ChoiceBox<Scenes> operations;

    private List<List<Double>> matrixData;
    @FXML
    private void initialize() {

        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.RREF);

        operations.setOnAction(event -> {
            Scenes selectedScene = operations.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    private void handleRREFFunctionality() {

    }

    @Override
    @FXML
    public void handleLoadButton() {

    }

    @Override
    @FXML
    public void handleSaveButton() {

    }

    @Override
    public void setMatrixData(File file) {

    }

    @Override
    public List<List<Double>> getMatrixData() {
        return matrixData;
    }
}
