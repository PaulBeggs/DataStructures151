package matrix.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import matrix.model.Matrix;
import matrix.model.MatrixView;

public class MatrixApp extends Application {
    private static Stage primaryStage;

    private Parent currentRoot;

    @Override
    public void start(Stage stage) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("matrixGUI.fxml"));
            currentRoot = loader.load();

            Data dataHandler = loader.getController();
            double[][] initialDataMatrix = dataHandler.getMatrixData();

            primaryStage = stage;


            Scene scene = new Scene(currentRoot);
            stage.setScene(scene);
            stage.show();
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }
    public Parent getCurrentRoot() {
        return this.currentRoot;
    }

    public static void main(String[] args) {
        launch(args);
    }
}
