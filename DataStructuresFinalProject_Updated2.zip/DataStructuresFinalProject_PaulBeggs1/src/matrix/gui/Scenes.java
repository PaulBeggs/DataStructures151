package matrix.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public enum Scenes {
    /*
     This enum is important because it allows brevity within the other classes.
     The "toString" method is simply there to accompany the choices within the box.
     */
    INVERSE {
        @Override
        public String toString() {
            return "Inverse";
        }

        @Override
        public void switchScene(ActionEvent event, MatrixView matrixView) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("inverseScene.fxml"));
            Parent currentRoot = matrixApp.getCurrentRoot();
            switchToScene(event, root, matrixView, currentRoot);
        }
    },
    DETERMINANT {
        @Override
        public String toString() {
            return "Determinant";
        }

        @Override
        public void switchScene(ActionEvent event, MatrixView matrixView) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("determinantScene.fxml"));
            Parent currentRoot = matrixApp.getCurrentRoot();
            switchToScene(event, root, matrixView, currentRoot);
        }
    },
    RREF {
        @Override
        public String toString() {
            return "RREF";
        }

        @Override
        public void switchScene(ActionEvent event, MatrixView matrixView) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("RREFScene.fxml"));
            Parent currentRoot = matrixApp.getCurrentRoot();
            switchToScene(event, root, matrixView, currentRoot);
        }
    },
    MATRIX {
        @Override
        public String toString() {
            return "Updated Matrix";
        }

        @Override
        public void switchScene(ActionEvent event, MatrixView matrixView) throws IOException {
            Parent root = FXMLLoader.load(getClass().getResource("matrixGUI.fxml"));
            Parent currentRoot = matrixApp.getCurrentRoot();
            switchToScene(event, root, matrixView, currentRoot);
        }
    };

    private Stage stage;
    private Scene scene;
    private MatrixView matrixView;
    public MatrixApp matrixApp;

    public abstract void switchScene(ActionEvent event, MatrixView matrixView) throws IOException;

    protected void switchToScene(ActionEvent event, Parent root, MatrixView matrixView, Parent currentRoot) {
        Stage stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);

        if (currentRoot != null && currentRoot.getId() != null && currentRoot.getId().equals("matrixGrid")) {
            matrixView.saveMatrixData();
        }

        stage.setScene(scene);
        stage.show();

        if (currentRoot != null && currentRoot.getId().equals("matrixGrid")) {
            matrixView.loadMatrixData(matrixView.getMatrixTextFields());
        }

        matrixApp.getCurrentRoot() = root;
    }

    private void loadMatrixData() {
        //todo
    }
}
