package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;
import matrix.operators.MatrixDeterminantOperations;
import matrix.operators.MatrixElementaryOperations;
import matrix.operators.MatrixInputHandler;

import java.io.File;
import java.io.IOException;
import java.util.List;

public class DeterminantController implements Data {
    @FXML
    Button loadButton, saveButton, findDeterminantButton;
    @FXML
    TextField sizeColsField, sizeRowsField;
    @FXML
    TextField targetRow, sourceRow;
    @FXML
    ChoiceBox<Scenes> scenes;
    @FXML
    Label output;
    private List<List<Double>> matrixData;
    private MatrixView matrixView;
    private MatrixElementaryOperations MEO;
    private Matrix matrix;
    private MatrixInputHandler MIH = new MatrixInputHandler();
    private int numCols, numRows;
    @FXML
    GridPane matrixGrid = new GridPane();
    @FXML
    TextField directions;
    private List<List<TextField>> matrixTextFields;

    @FXML
    private void initialize() {
        scenes.getItems().setAll(Scenes.MATRIX, Scenes.DETERMINANT);
        scenes.setValue(Scenes.DETERMINANT);

        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

    }



    @FXML
    public void handleDeterminantFunctionality() {
        MatrixDeterminantOperations determinantOperations = new MatrixDeterminantOperations(matrix, matrixView);
        System.out.print("Determinant of the matrix is: " + determinantOperations.calculateDeterminant());
    }

    @Override
    @FXML
    public void handleSaveButton() {

    }

    @Override
    @FXML
    public void handleLoadButton() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showOpenDialog(new Stage());
        setMatrixData(file);
    }

    @Override
    public void setMatrixData(File file) {

        if (file != null) {
            String filePath = file.getAbsolutePath();
            List<List<Double>> loadedMatrix = MatrixFileHandler.loadMatrixFromFile(filePath);

            // Updating UI with the loaded matrix
            matrixView.loadMatrixData(loadedMatrix);
        }
    }

    @Override
    public List<List<Double>> getMatrixData() {
        return matrixData;
    }
}

