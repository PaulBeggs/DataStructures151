package matrix.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class InverseController implements Data {
    @FXML
    TextField multiplier;
    @FXML
    TextField sourceRow;
    @FXML
    TextField targetRow;
    @FXML
    Button compute;
    @FXML
    ChoiceBox<Scenes> operations;
    List<List<Double>> matrixData;
    @FXML
    private void initialize() {

        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.INVERSE);

        operations.setOnAction(event -> {
            Scenes selectedScene = operations.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void handleInvertingFunctionality() {

    }

    @Override
    @FXML
    public void handleLoadButton() {

    }

    @Override
    @FXML
    public void handleSaveButton() {

    }

    @Override
    public void setMatrixData(File file) {

    }

    @Override
    public List<List<Double>> getMatrixData() {
        return matrixData;
    }
}
