package matrix.gui;

import javafx.fxml.FXML;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public interface Data {
    @FXML
    void handleLoadButton();
    @FXML
    void handleSaveButton();
    void setMatrixData(File file);

    List<List<Double>> getMatrixData();
}
