package matrix.gui;

import java.util.List;

public interface MatrixFileHandlerInterface {
    List<List<Double>> loadMatrixFromFile(String filePath);
    void saveMatrixToFile(String filePath, List<List<Double>> matrixData);
}

