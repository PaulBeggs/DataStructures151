module MatrixInJavaFXSample {
    requires javafx.controls;
    requires javafx.graphics;
    requires javafx.fxml;
    exports Matrix;
    opens Matrix;
}