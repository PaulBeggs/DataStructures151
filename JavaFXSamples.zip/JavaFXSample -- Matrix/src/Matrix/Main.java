package Matrix;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Random;

public class Main extends Application {

    @FXML
    Button GenerateButton;
    @FXML
    TextField sizeField;

    GridPane matrix = new GridPane();
    Scene matrixScene;

    @Override
    public void start(Stage primaryStage) throws IOException {
        GridPane root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        Scene scene = new Scene(root, 500, 500);
        primaryStage.setTitle("Matrix");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    void onButtonClickGenerate(ActionEvent event) {
        int size = Integer.parseInt(sizeField.getText());
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                int value = 0;
                // Create a new TextField in each Iteration
                TextField tf = new TextField();
                tf.setPrefHeight(50);
                tf.setPrefWidth(50);
                tf.setAlignment(Pos.CENTER);
                tf.setEditable(false);
                tf.setText(String.valueOf(value));
                matrix.setRowIndex(tf, y);
                matrix.setColumnIndex(tf, x);
                matrix.getChildren().add(tf);
            }
        }
        matrixScene = new Scene(matrix, 500, 500);
        Stage stage = ((Stage)((Button)(event.getSource())).getScene().getWindow());
        stage.setScene(matrixScene);
    }

    public static void main(String[] args) {
        launch(args);
    }
}