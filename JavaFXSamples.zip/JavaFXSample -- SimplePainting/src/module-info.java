module PaintingExampleFromInternet {
    requires javafx.fxml;
    requires javafx.controls;
    requires javafx.graphics;
    opens paint;
    exports paint;
}