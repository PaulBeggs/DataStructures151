package paint;

public class PaintingController {
}
