module AnimationDemo {
    requires javafx.fxml;
    requires javafx.controls;
    exports demo;
    opens demo;
}