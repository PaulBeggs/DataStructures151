package demo;

import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

public class BlocksView extends Parent {

    private Block block;
    private Rectangle r;

    public BlocksView(Block block) {
        this.block = block;

        r = new Rectangle(50, 50, 100, 100);
        r.setFill(Color.AQUAMARINE);
        r.setStroke(Color.BLACK);
        r.setOnMouseDragged(event -> drag(event, block));
        r.setOnMousePressed(event -> pressed(event, block));
        r.setOnMouseReleased(event -> released(event, block));
        getChildren().add(r);
    }

    // What to do when the mouse is Pressed
    private void pressed(MouseEvent event, Block b) {
        b.toggleMovement();
        r.setFill(Color.MEDIUMPURPLE);
        event.consume();
    }

    // What to do when the mouse is Released
    private void released(MouseEvent event, Block b) {
        b.toggleMovement();
        r.setFill(Color.ORANGE);
    }

    // What to do when the mouse is Dragged
    private void drag(MouseEvent event, Block b) {
        b.setX(b.getX() + event.getX());
        b.setY(b.getY() + event.getY());
        update();
    }

    public void update() {
        r.setHeight(block.getLength());
        r.setWidth(block.getWidth());
        r.setTranslateX(block.getX());
        r.setTranslateY(block.getY());
    }
}
