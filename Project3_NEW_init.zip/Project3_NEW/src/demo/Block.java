package demo;

public class Block {

	private double x;
	private double y;
	private double dx;
	private double dy;
	private double length;
	private double width;
	private boolean canMove;

	public Block(double width, double length) {
		this.length = length;
		this.width = width;
		x = length + (Math.random() * (200 - (2 * length)));
		y = length + (Math.random() * (200 - (2 * length)));

		dx = Math.random() * 2 - 1;
		dy = Math.random() * 2 - 1;

		canMove = true;
	}

	public void setX(double x) {
		this.x = x;
	}

	public void setY(double y) {
		this.y = y;
	}

	public double getX() {
		return x;
	}

	public double getY() {
		return y;
	}

	public double getLength() {return length; }

	public double getWidth() {return width; }

	public void toggleMovement() { canMove = !canMove; }

	public void move() {
		if (canMove) {
			x += dx;
			double over = Math.max(0, x + length - 200);
			over = Math.max(over, length - x);
			if (over > 0) {
				dx *= -1;
				x += Math.signum(dx) * over;
			}

			y += dy;
			over = Math.max(0, y + length - 200);
			over = Math.max(over, length - y);
			if (over > 0) {
				dy *= -1;
				y += Math.signum(dy) * over;
			}
		}
	}
	public void setDimensions(double length, double width) {
		this.length = length;
		this.width = width;
	}
}
