package demo;

import java.util.ArrayList;

import javafx.animation.AnimationTimer;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class BlocksController {

	@FXML
	private Pane pane;

	private ArrayList<Block> rectangles;
	private ArrayList<BlocksView> bvs;

	private Movement clock;

	private class Movement extends AnimationTimer {

		private long FRAMES_PER_SEC = 50L;
		private long INTERVAL = 1000000000L / FRAMES_PER_SEC;

		private long last = 0;
		private double length = 50;
		private double width = 100;
		private ArrayList<Block> bs;

		public void setBlocks(ArrayList<Block> bs) {
			this.bs = bs;
		}

		@Override
		public void handle(long now) {
			if (now - last > INTERVAL) {
				for (Block b : bs) {
					b.move();
					b.setDimensions(length, width);
				}
				updateViews();
				last = now;
			}
		}
	}

	@FXML
	public void initialize() {
		rectangles = new ArrayList<Block>();
		bvs = new ArrayList<BlocksView>();

		for (int i = 0; i < 5; i++) {
			makeBlock();
		}

		clock = new Movement();
		clock.setBlocks(rectangles);
		clock.start();
		pane.setOnMousePressed(event -> {
			makeBlock();
		});
		makeBlock();
	}
	@FXML
	public void start() {
		clock.start();
	}
	@FXML
	public void stop() {
		clock.stop();
	}

	@FXML
	private void makeBlock() {
		Block b = new Block(50, 100);
		rectangles.add(b);

		BlocksView bv = new BlocksView(b);
		bvs.add(bv);
		pane.getChildren().add(bv);

		updateViews();
	}

	private void updateViews() {
		for (BlocksView bv : bvs) {
			bv.update();
		}
	}
}
