package matrix.model;

import matrix.operators.MatrixInputHandler;

public class MatrixView {
    private MatrixInputHandler inputHandler;
    private Matrix matrix;


    public MatrixView(Matrix matrix) {
        this.matrix = matrix;
    }

    public Matrix getMatrix() {
        return matrix;
    }

    public void setMatrixValues() {
        // todo

        for (int row = 0; row < matrix.getRows(); row++) {
            for (int col = 0; col < matrix.getCols(); col++) {
                // todo
            }
        }
    }




    public void update() {

    }
}