package matrix.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class InverseController {
    @FXML
    TextField multiplier;
    @FXML
    TextField sourceRow;
    @FXML
    TextField targetRow;
    @FXML
    Button compute;
    @FXML
    ChoiceBox<Scenes> operations;
    @FXML
    private void initialize() {

        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.INVERSE);

        operations.setOnAction(event -> {
            Scenes selectedScene = operations.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void handleInvertingFunctionality() {

    }
}
