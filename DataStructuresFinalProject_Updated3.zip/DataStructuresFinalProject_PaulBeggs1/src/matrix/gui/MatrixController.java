package matrix.gui;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import matrix.operators.MatrixElementaryOperations;
import matrix.operators.MatrixInputHandler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class MatrixController {
    @FXML
    TextField multiplier;
    @FXML
    Button generateButton;
    @FXML
    Button saveButton;
    @FXML
    Button operationButton;
    @FXML
    TextField sizeColsField;
    @FXML
    TextField sizeRowsField;
    @FXML
    ChoiceBox<Scenes> scenes;
    @FXML
    TextField targetRow;
    @FXML
    TextField sourceRow;
    @FXML
    ChoiceBox<String> operations;
    private MatrixView matrixView;
    private MatrixElementaryOperations MEO;
    private Matrix matrix;
    private MatrixInputHandler MIH = new MatrixInputHandler();
    private int numCols, numRows;
    @FXML
    GridPane matrixGrid = new GridPane();
    @FXML
    TextField directions;
    private List<List<TextField>> matrixTextFields;

    @FXML
    private void initialize() {
        this.MEO = new MatrixElementaryOperations(matrix, matrixView);

        numCols = Integer.parseInt(sizeColsField.getText());
        numRows = Integer.parseInt((sizeRowsField.getText()));

        this.matrix = new Matrix(numRows, numCols);

        matrixTextFields = new ArrayList<>();

        operations.getItems().addAll("Swap Rows", "Multiply Rows", "Add Rows");
        operations.setValue("Swap Rows");

        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.MATRIX);

        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.getMessage();
            }
        });

        directions.setEditable(false);
        directions.setText("Click 'generate' to produce a Matrix. The cells are editable;" +
                " use 'tab' to go through each cell and add an entry.");
    }


    @FXML
    public void handleGenerateButton() {
        matrixGrid.getChildren().clear();
        numRows = Integer.parseInt(sizeRowsField.getText());
        numCols = Integer.parseInt(sizeColsField.getText());

//        System.out.println("Rows Text " + numRows);
//        System.out.println("Cols Text " + numCols);

        if (MIH.isPositiveIntValid(sizeColsField) && MIH.isPositiveIntValid(sizeRowsField)) {
            for (int row = 0; row < numRows; row++) {
                List<TextField> rowList = new ArrayList<>();
                for (int col = 0; col < numCols; col++) {
                    TextField cell = new TextField();
                    cell.setMinHeight(50);
                    cell.setMinWidth(50);
                    cell.setAlignment(Pos.CENTER);
                    cell.setEditable(true);

                    double randomValue = Math.floor(Math.random() * 100) / 10.0;
                    cell.setText(String.valueOf(randomValue));
                    matrixGrid.add(cell, col, row);

                    rowList.add(cell);
                }
                matrixTextFields.add(rowList);
            }
        } else {
            System.out.println("Invalid Row Indices.");
        }
    }

    @FXML
    private void handleSaveButton() {
        List<List<String>> matrixData = new ArrayList<>();

        for (List<TextField> row : matrixTextFields) {
            List<String> rowData = row.stream().map(TextField::getText).collect(Collectors.toList());
            matrixData.add(rowData);
        }

// Load the SaveScene FXML
        FXMLLoader loader = new FXMLLoader(getClass().getResource("SaveScene.fxml"));
        Parent root;
        try {
            root = loader.load();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

// Create the SaveScene controller
        SaveSceneController saveSceneController = loader.getController();
        saveSceneController.setMatrixTextFields(matrixTextFields);

// Rest of your code...


        // Create a new stage for the SaveScene
        Stage saveStage = new Stage();
        saveStage.setTitle("Save Matrix");
        saveStage.initModality(Modality.WINDOW_MODAL);
        saveStage.initOwner(MatrixApp.getPrimaryStage());
        saveSceneController.setStage(saveStage);
        Scene saveScene = new Scene(root);
        saveStage.setScene(saveScene);
        saveStage.showAndWait();



        // Set the SaveScene controller's stage
        saveSceneController.setStage(saveStage);

        // After the SaveScene is closed, retrieve the file name from SaveSceneController
        String fileName = saveSceneController.getFileName();

        if (fileName != null && !fileName.isEmpty()) {
            // Call the method to save the matrix with the specified file name
            MatrixFileHandler.saveMatrixToFile("matrices/" + fileName + ".txt", matrixData);
        }
    }



    @FXML
    private void handleLoadButton() {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        File file = fileChooser.showOpenDialog(new Stage());

        if (file != null) {
            String filePath = file.getAbsolutePath();
            List<List<String>> loadedMatrix = MatrixFileHandler.loadMatrixFromFile(filePath);

            // Update your UI (matrixTextFields) with the loaded matrix
            for (int i = 0; i < loadedMatrix.size(); i++) {
                List<String> rowValues = loadedMatrix.get(i);
                for (int j = 0; j < rowValues.size(); j++) {
                    String cellValue = rowValues.get(j);
                    matrixTextFields.get(i).get(j).setText(cellValue);
                }
            }
        }
    }

    @FXML
    private void performOperation() {
        String selectedOption = operations.getValue();

        if (MIH.isRowValid(targetRow, matrix.getRows()) && MIH.isRowValid(sourceRow, matrix.getRows())) {
            int targetRowIndex = Integer.parseInt(targetRow.getText()) - 1;
            int sourceRowIndex = Integer.parseInt(sourceRow.getText()) - 1;


            switch (selectedOption) {
                case "Swap Rows" -> {
                    MEO.swapRows(targetRowIndex, sourceRowIndex);
                    updateSwappedMatrixUI(targetRowIndex, sourceRowIndex);

                }
                case "Multiply Rows", "Add Rows" -> {
                    if (MIH.isDoubleValid(multiplier)) {
                        double rowMultiplier = Double.parseDouble(multiplier.getText());

                        if (selectedOption.equals("Multiply Rows")) {
                            MEO.multiplyRow(targetRowIndex, rowMultiplier);
                            updateMultipliedMatrixUI(targetRowIndex, rowMultiplier);

                        } else {
                            MEO.addRows(targetRowIndex, sourceRowIndex, rowMultiplier);
                            updateAddedMatrixUI(targetRowIndex, sourceRowIndex, rowMultiplier);
                        }

                    } else {
                        System.out.println("Invalid Multiplier. Please enter a valid double.");
                    }
                }
            }
        } else {
                System.out.println("At least one row is invalid. Fix it to proceed.");
        }
    }

    private void updateSwappedMatrixUI(int targetRowIndex, int sourceRowIndex) {
        int numCols = matrix.getCols();
        try {
            for (int col = 0; col < numCols; col++) {
                String temp = matrixTextFields.get(targetRowIndex).get(col).getText();
                matrixTextFields.get(targetRowIndex).get(col).setText(matrixTextFields.get(sourceRowIndex).get(col).getText());
                matrixTextFields.get(sourceRowIndex).get(col).setText(temp);
            }

            } catch (Exception e) {
                targetRow.clear();
                sourceRow.clear();
                System.out.println("An unexpected error occurred : " + e.getMessage());
            }
    }
    private void updateMultipliedMatrixUI(int targetRowIndex, double rowMultiplier) {
        // todo
        int numCols = matrix.getCols();
        try {
            for (int col = 0; col < numCols; col++) {
                double currentValue = Double.parseDouble(matrixTextFields.get(targetRowIndex).get(col).getText());

                double multipliedValue = currentValue * rowMultiplier;

                matrixTextFields.get(targetRowIndex).get(col).setText(String.valueOf(multipliedValue));
            }
        } catch (NumberFormatException e) {
            System.out.println("Error converting text to double: " + e.getMessage());
//        } catch (Exception e) {
//            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

    private void updateAddedMatrixUI(int targetRowIndex, int sourceRowIndex, double rowMultiplier) {
        int numCols = matrix.getCols();
        try {
            for (int col = 0; col < numCols; col++) {
                // Get the values from the target and source cells
                double targetValue = Double.parseDouble(matrixTextFields.get(targetRowIndex).get(col).getText());
                double sourceValue = Double.parseDouble(matrixTextFields.get(sourceRowIndex).get(col).getText());

                // Add the values with the specified multiplier
                double addedValue = targetValue + rowMultiplier * sourceValue;

                // Update the target cell with the result
                matrixTextFields.get(targetRowIndex).get(col).setText(String.valueOf(addedValue));
            }
        } catch (NumberFormatException e) {
            System.out.println("Error converting text to double: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }

}
