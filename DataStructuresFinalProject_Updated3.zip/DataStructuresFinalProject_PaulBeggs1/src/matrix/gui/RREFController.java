package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class RREFController {
    @FXML
    TextField rowOne;
    @FXML
    TextField rowTwo;
    @FXML
    Button switchButton;
    @FXML
    ChoiceBox<Scenes> operations;
    @FXML
    private void initialize() {

        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.RREF);

        operations.setOnAction(event -> {
            Scenes selectedScene = operations.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    private void handleRREFFunctionality() {

    }
}
