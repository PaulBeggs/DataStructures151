package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import matrix.model.MatrixFileHandler;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class SaveSceneController {
    @FXML
    private TextField fileNameField;
    private List<List<TextField>> matrixTextFields;

    private String fileName;
    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;

    }
    public void setMatrixTextFields(List<List<TextField>> matrixTextFields) {
        this.matrixTextFields = matrixTextFields;
    }

    @FXML
    private void saveButtonPressed() {
        String fileName = fileNameField.getText().trim();

        // Validate the file name (add your validation logic)
        if (!fileName.isEmpty() && !fileName.contains(File.separator) && !fileName.contains(".")) {
            // Call the method to save the matrix with the specified file name
            List<List<String>> matrixData = getMatrixDataFromTextFields();
            MatrixFileHandler.saveMatrixToFile("matrices/" + fileName + ".txt", matrixData);

            // Close the SaveScene
            stage.close();
        } else {
            // Show an error message or handle invalid input
            System.out.println("Please enter a valid file name without special characters or file extensions.");
        }
    }

    private List<List<String>> getMatrixDataFromTextFields() {
        List<List<String>> matrixData = new ArrayList<>();

        for (List<TextField> row : this.matrixTextFields) {
            List<String> rowData = row.stream().map(TextField::getText).collect(Collectors.toList());
            matrixData.add(rowData);
        }

        return matrixData;
    }


    public String getFileName() {
        return fileName;
    }
}
