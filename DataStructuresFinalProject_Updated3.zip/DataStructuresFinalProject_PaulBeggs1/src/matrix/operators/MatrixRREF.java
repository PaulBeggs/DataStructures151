package matrix.operators;

import matrix.model.Matrix;

public class MatrixRREF implements RREF {

    private Matrix matrix;

    @Override
    public boolean isValidRow(int row) {
        return row >= 0 && row < matrix.getRows();
    }
    @Override
    public boolean isValidCol(int col) {
        return col >= 0 && col < matrix.getCols();
    }
}
