package matrix.operators;

public interface Elementary {
    boolean isValidRow(int row);
    boolean isValidCol(int col);
}
