public class Main {
    public static void main(String[] args) {
        TootsiePop p = new TootsiePop("Strawberry", 40);
        System.out.println("Initial state: " + p.toString());

//        while (p.canLick()) {
//            p.lick();
//            System.out.println("After licking: " + p.toString());
//        }

//        p.bite();
//        System.out.println("After biting: " + p.toString());
    }
}

// To exercise each function, uncomment the one that you are wanting to test.