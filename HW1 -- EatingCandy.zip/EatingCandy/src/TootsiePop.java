public class TootsiePop {

    public String flavor;
    public int numLicks;

    public TootsiePop(String flavor, int initialLicks) {
        this.flavor = flavor;
        this.numLicks = initialLicks;
    }

    public boolean canLick() {
        return numLicks > 0;
    }

    public void lick() {
        if (canLick()) {
            numLicks--;
        }
    }

    public void bite() {
        numLicks = 0;
    }

    public String toString() {
        return flavor.toLowerCase() + ": " + numLicks;
    }
}
