package matrix.operators;

public interface RREF {
}
