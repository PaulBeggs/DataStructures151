package matrix.operators;

import matrix.model.Matrix;
import matrix.model.MatrixView;

import java.io.IOException;

public class MatrixElementaryOperations implements Elementary {
    private MatrixView matrixView;
    private Matrix matrix;

    public MatrixElementaryOperations(Matrix matrix, MatrixView matrixView) {
        this.matrixView = matrixView;
        this.matrix = matrix;
    }

    public void swapRows(int row1, int row2) {
        if (this.matrix != null && isValidRow(row1) && isValidRow(row2)) {
            double[] temp = this.matrix.getMatrix()[row1];
            this.matrix.getMatrix()[row1] = this.matrix.getMatrix()[row2];
            this.matrix.getMatrix()[row2] = temp;
        }
    }

    public void multiplyRow(int row, double multiplier) {
        if (this.matrix != null && isValidRow(row)) {
            for (int col = 0; col < this.matrix.getCols(); col++) {
                this.matrix.getMatrix()[row][col] *= multiplier;
            }
        }
    }

    public void addRows(int sourceRow, int targetRow, double multiplier) {
        if (this.matrix != null && isValidRow(sourceRow) && isValidRow(targetRow)) {
            for (int col = 0; col < this.matrix.getCols(); col++) {
                this.matrix.getMatrix()[targetRow][col] += multiplier * this.matrix.getMatrix()[sourceRow][col];
            }
        }
    }


    @Override
    public boolean isValidRow(int row) {
        return row >= 0 && row < matrix.getRows();
    }
    @Override
    public boolean isValidCol(int col) {
        return col >= 0 && col < matrix.getCols();
    }
}
