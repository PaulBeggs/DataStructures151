package matrix.gui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class RowSwapController {
    @FXML
    TextField rowOne;
    @FXML
    TextField rowTwo;
    @FXML
    Button switchButton;
    @FXML
    ChoiceBox<Scenes> operations;
    @FXML
    private void initialize() {
        /*
         "operations" is the choice box in which the user can choose which
           scene they want to go to.
         This is later accessed in the "handleSwitchButton(event)" that is
           available in every controller.
         This, and the message within "handleSwitchButton(event)" are
           duplicates.
         */
        operations.getItems().setAll(Scenes.values());
        operations.setValue(Scenes.ROW);

        operations.setOnAction(event -> {
            Scenes selectedScene = operations.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    private void handleRowSwapFunctionality() {

    }
}
