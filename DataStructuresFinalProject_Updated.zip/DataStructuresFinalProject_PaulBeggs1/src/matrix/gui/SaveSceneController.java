package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class SaveSceneController {
    @FXML
    private TextField fileNameField;

    private Stage stage;

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    @FXML
    private void saveButtonPressed() {
        String fileName = fileNameField.getText().trim();

        // Validate the file name (add your validation logic)
        if (!fileName.isEmpty()) {
            // Call the method to save the matrix with the specified file name
            // Example: MatrixFileHandler.saveMatrixToFile("matrices/" + fileName + ".txt", matrixData);

            // Close the SaveScene
            stage.close();
        } else {
            // Show an error message or handle invalid input
            System.out.println("Please enter a valid file name.");
        }
    }
}
