package matrix.model;

public class Matrix {

    private double[][] matrix;
    private Integer numCols;
    private Integer numRows;

    public Matrix(int numRows, int numCols) {
        this.numRows = numRows;
        this.numCols = numCols;
        matrix = new double[numRows][numCols];
        //todo
    }

    public double[][] getMatrix() {
        return matrix;
    }

    public int getRows() {
        return matrix.length;
    }

    public int getCols() {
        return matrix[0].length;
    }

    public boolean isValidRow(int row) {
        return row >= 0 && row < numRows;
    }

    private boolean isValidColumn(int col) {
        return col >= 0 && col < numCols;
    }
}
