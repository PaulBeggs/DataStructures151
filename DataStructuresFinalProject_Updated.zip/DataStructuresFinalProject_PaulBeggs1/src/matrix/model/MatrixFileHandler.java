package matrix.model;

import java.io.*;
import java.util.List;

public class MatrixFileHandler {

    public static void saveMatrixToFile(String filePath, List<List<String>> matrixData) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (List<String> row : matrixData) {
                String rowString = String.join(" ", row);
                writer.write(rowString);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<List<String>> loadMatrixFromFile(String filePath) {
        List<List<String>> matrixData = null;

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            matrixData = reader.lines()
                    .map(line -> List.of(line.split(" ")))
                    .toList();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return matrixData;
    }
}
