package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;

import java.io.IOException;

public class DeterminantController implements DataManipulation {

    @FXML
    Button saveButton;
    @FXML
    Button loadButton;
    @FXML
    TextField multiplier;
    @FXML
    TextField targetRow;
    @FXML
    Button compute;
    @FXML
    ChoiceBox<Scenes> scenes;

    @FXML
    private void initialize() {
        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.DETERMINANT);

        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void handleDeterminantFunctionality() {
    }

    @Override
    public void handleSaveButton() {

    }

    @Override
    public void handleLoadButton() {

    }

    @Override
    public void update() {

    }
}

