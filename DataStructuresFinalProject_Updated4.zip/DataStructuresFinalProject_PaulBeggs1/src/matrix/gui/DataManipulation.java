package matrix.gui;

public interface DataManipulation {
    void handleSaveButton();
    void handleLoadButton();
    void update();
}
