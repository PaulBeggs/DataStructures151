package matrix.operators;

import matrix.model.Matrix;
import matrix.model.MatrixView;

public class MatrixDeterminantOperations {

    private MatrixView matrixView;
    private Matrix matrix;

    public MatrixDeterminantOperations(Matrix matrix, MatrixView matrixView) {
        this.matrixView = matrixView;
        this.matrix = matrix;
    }

    // Function to get cofactor of mat[p][q] in temp[][]
    private void getCofactor(int p, int q, int n, double[][] temp) {
        int i = 0, j = 0;

        for (int row = 0; row < n; row++) {
            for (int col = 0; col < n; col++) {
                if (row != p && col != q) {
                    temp[i][j++] = matrix.getMatrix()[row][col];
                    if (j == n - 1) {
                        j = 0;
                        i++;
                    }
                }
            }
        }
    }

    // Recursive function for finding determinant of matrix
    private double determinantOfMatrix(double[][] mat, int n) {
        double D = 0;

        // Base case: if matrix contains a single element
        if (n == 1)
            return mat[0][0];

        // To store cofactors
        double[][] temp = new double[n][n];

        // To store sign multiplier
        double sign = 1;

        // Iterate for each element of the first row
        for (int f = 0; f < n; f++) {
            getCofactor(0, f, n, temp);
            D += sign * mat[0][f] * determinantOfMatrix(temp, n - 1);

            // Terms are to be added with alternate sign
            sign = -sign;
        }
        return D;
    }

    // Public method to calculate determinant
    public double calculateDeterminant() {
        if (matrix.getRows() == matrix.getCols()) {
            return determinantOfMatrix(matrix.getMatrix(), matrix.getRows());
        } else {
            System.out.println("Determinant is not defined for non-square matrices.");
            return 0;
        }
    }
}
