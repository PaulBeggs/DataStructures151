module Acquire {
    requires javafx.graphics;
    requires javafx.fxml;
    requires javafx.controls;

    exports Acquire.core;
    opens Acquire.gui;
}