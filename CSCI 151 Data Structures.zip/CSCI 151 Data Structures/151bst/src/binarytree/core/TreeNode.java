package binarytree.core;

import java.util.Optional;
import java.util.function.Consumer;

public class TreeNode<T extends Comparable<T>> {
	private Optional<TreeNode<T>> left = Optional.empty();
	private Optional<TreeNode<T>> right = Optional.empty();
	private T value;
	
	public TreeNode(T value) {
		this.value = value;
	}

	public T get() {return value;}
	public Optional<TreeNode<T>> getLeft() {return left;}	
	public Optional<TreeNode<T>> getRight() {return right;}
	public boolean isLeaf() {return left.isEmpty() && right.isEmpty();}
	
	public void insert(T value) {
		int comp = value.compareTo(this.value);
		if (comp < 0) {
			if (left.isEmpty()) {
				left = Optional.of(new TreeNode<>(value));
			} else {
				left.get().insert(value);
			}
		} else if (comp > 0) {
			if (right.isEmpty()) {
				right = Optional.of(new TreeNode<>(value));
			} else {
				right.get().insert(value);
			}
		}
		// Insert a new node containing value, preserving the ordering.
		//
		// Compare the parameter to this.value to determine which direction to go.
		// If the parameter is less than this.value, proceed with the left child.
		// If the parameter is greater than this.value, proceed with the right child.
		// If the child is empty, replace it with a new Optional<TreeNode>
		// containing the value.
		// Otherwise, call insert recursively on the child.
	}
	
	public boolean contains(T value) {
		int comp = value.compareTo(this.value);
		if (comp == 0) {
			return true;
		} else if (comp < 0) {
			if (left.isEmpty()) {
				return false;
			} else {
				return left.get().contains(value);
			}
		} else {
			if (right.isEmpty()) {
				return false;
			} else {
				return right.get().contains(value);
			}
		}
		// Return true if value is present in the tree, false otherwise
		//
		// Compare the parameter to this.value to determine which direction to go.
		// If the parameter is equal to this.value, return true
		// If the parameter is less than this.value, proceed with the left child.
		// If the parameter is greater than this.value, proceed with the right child.
		// If the child is empty, return false.
		// Otherwise, call contains recursively on the child.
	}
	
	public int height() {
		int leftnum = 0;
		int rightnum = 0;
		if (left.isPresent()) {
			leftnum = 1 + left.get().height();
		}
		if (right.isPresent()) {
			rightnum = 1 + right.get().height();
		}
		if (leftnum > rightnum) {
			return leftnum;
		} else {
			return rightnum;
		}
		// Return the height of the tree, which is the maximum number of
		// edges between the root and any leaf.
	}
	
	public int size() {
		if (isLeaf()) {
			return 1;
		} else if (right.isEmpty()) {
			return 1 + left.get().size();
		} else if (left.isEmpty()) {
			return 1 + right.get().size();
		} else {
			return 1 + left.get().size() + right.get().size();
		}
		// Return the number of nodes in the tree, which is 1 + the number of
		// nodes in the child trees.
	}
	
	public T getMin() {
		if (isLeaf() || left.isEmpty()) {
			return value;
		}
		return left.get().getMin();
	}
	
	public T getMax() {
		if (isLeaf() || right.isEmpty()) {
			return value;
		}
		return right.get().getMax();
	}

	public void preOrder(Consumer<T> op) {
		op.accept(value);
		if (left.isPresent()) {
			left.get().preOrder(op);
		}
		if (right.isPresent()) {
			right.get().preOrder(op);
		}
		// Perform a preorder traversal using op.accept(value)
	}
	
	public void postOrder(Consumer<T> op) {
		if (left.isPresent()) {
			left.get().postOrder(op);
		}
		if (right.isPresent()) {
			right.get().postOrder(op);
		}
		op.accept(value);
		// Perform a postorder traversal using op.accept(value)
	}
	
	public void inOrder(Consumer<T> op) {
		if (left.isPresent()) {
			left.get().inOrder(op);
		}
		op.accept(value);
		if (right.isPresent()) {
			right.get().inOrder(op);
		}
		// Perform an inorder traversal using op.accept(value)
	}

	public Optional<TreeNode<T>> remove(T target) {
		int comp = target.compareTo(this.value);
		if (comp < 0) {
			if (left.isPresent()) {
				left = left.get().remove(target);
			}
		} else if (comp > 0) {
			if (right.isPresent()) {
				right = right.get().remove(target);
			}
		} else if (comp == 0) {
			if (isLeaf()) {
				return Optional.empty();
			} else if (right.isPresent() && left.isEmpty()) {
				return right;
			} else if (left.isPresent() && right.isEmpty()) {
				return left;
			} else if (left.isPresent() && right.isPresent()) {
				this.value = left.get().getMax();
				left = left.get().remove(this.value);
			}
		}
		return Optional.of(this);
		// - If target is less than value:
		//   - Set the left child to be the result of calling this method recursively.
		// - If target is greater than value:
		//   - Set the right child to be the result of calling this method recursively.
		// - If target and value are equivalent:
		//   - If it is at a leaf, return Optional.empty()
		//   - If it has exactly one child, return that child
		//   - If it has two children, set the current value to the maximum value of the left child,
		//     Then set the left child to the result of a recursive call
		//     with that maximum value as the parameter.
	}

	/* Removed for simplicity
	public TreeNode<T> leftRotateAt(T value) {
		// TODO:
		// - If value is present in the tree, perform a left rotation of
		//   the node containing it, and return its new parent node.
		// - If value is not present, just return this.
		return this;
	}

	public TreeNode<T> rightRotateAt(T value) {
		// TODO:
		// - If value is present in the tree, perform a right rotation of
		//   the node containing it, and return its new parent node.
		// - If value is not present, just return this.
		return this;
	}

	 */
}
