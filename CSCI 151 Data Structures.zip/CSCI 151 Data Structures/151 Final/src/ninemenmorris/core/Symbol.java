package ninemenmorris.core;

public enum Symbol {
	EMPTY {
		@Override
		public char rep() {
			return ' ';
		}

		@Override
		public Status win() {
			throw new UnsupportedOperationException();
		}

		@Override
		public Status lose() {
			throw new UnsupportedOperationException();
		}
	}, UNUSABLE {
		@Override
		public char rep() {
			throw new UnsupportedOperationException();
		}

		@Override
		public Status win() {
			throw new UnsupportedOperationException();
		}

		@Override
		public Status lose() {
			throw new UnsupportedOperationException();
		}
	}, B {
		@Override
		public char rep() {
			return 'B';
		}

		@Override
		public Status win() {
			return Status.B_WIN;
		}

		@Override
		public Status lose() {
			return Status.W_WIN;
		}
	}, W {
		@Override
		public char rep() {
			return 'W';
		}

		@Override
		public Status win() {
			return Status.W_WIN;
		}

		@Override
		public Status lose() {
			return Status.B_WIN;
		}
	};
	
	abstract public char rep();
	abstract public Status win();
	abstract public Status lose();
}
