package ninemenmorris.learn;

import java.util.ArrayList;
import java.util.Optional;

@SuppressWarnings("unchecked")
public class HashTable<K,V> {
	private HashNode<K,V>[] table;
	private int size;
	private final double MAX_LOAD = 0.75;
    
    public HashTable() {
		initTable(16);
    }
	
	private void initTable(int size) {
		table = (HashNode<K,V>[]) new HashNode[size];
		this.size = 0;
	}
	
	public int size() {
		return size;
	}
	
	int capacity() {
		return table.length;
	}
	
	public double load() {
		return (double)size() / capacity();
	}

	/**
	 * @param key
	 * @return Index associated with key, given the size of the table.
	 */
	int index(K key) {
		int index = Math.abs(key.hashCode() % table.length);
		return index;
	}

	/**
	 * Stores a value in the HashTable for the given key.
	 * Implement the separate chaining method of resolving
	 * collisions in the table.
	 * @param key
	 * @param value
	 */
	public void put(K key, V value) {
		int index = index(key);
		if (table[index] != null) {
			boolean eaten = false;
			for (HashNode<K, V> spot = table[index]; spot != null; spot = spot.getNext()) {
				if (spot.getKey().equals(key)) {
					spot.setValue(value);
					break;
				} else if (spot.getNext() == null && !spot.getKey().equals(key)){
					table[index] = new HashNode<>(key, value, table[index]);
					size++;
					break;
				}
			}
		} else {
			table[index] = new HashNode<K,V>(key, value);
			size++;
		}
		if (load() > MAX_LOAD) {
			HashNode<K, V>[] oldtable = table.clone();
			initTable(table.length * 2);
			for (int i = 0; i < oldtable.length; i++) {
				for (HashNode<K, V> spot = oldtable[i]; spot != null; spot = spot.getNext()) {
					put(spot.getKey(), spot.getValue());
				}
			}
		}
	}

	/**
	 * Retrieves the value stored in the table when given a key, if present.
	 */
	public Optional<V> get(K key) {
		int index = index(key);
		if (table[index] != null) {
			for (HashNode<K,V> spot = table[index]; spot != null;) {
				if (spot.getKey().equals(key)) {
					if (spot.getValue() != null) {
						return Optional.of(spot.getValue());
					}
					if (spot.getNext() == null) {
						return Optional.empty();
					}
				}
				spot = spot.getNext();
			}
		}
		return Optional.empty();
	}
	
	/**
	 * Returns a list of all the keys found in the HashTable.
	 * @return
	 */
	public ArrayList<K> allKeys() {
		ArrayList<K> all = new ArrayList<>();
		for (int i = 0; i < table.length; i++) {
			for (HashNode<K,V> spot = table[i]; spot != null; spot = spot.getNext()) {
				all.add(spot.getKey());
			}
		}
		return all;
	}
	
}
