package sorting.algorithms;

import java.util.ArrayList;

public class BubbleSorter<E extends Comparable<E>> extends Sorter<E> {

    @Override
    protected void sortAlgorithm(ArrayList<E> array) {
        for (int i = array.size() - 1; i > 0; i--) {
            int index = 0;
            while (index < i) {
                if (array.get(index).compareTo(array.get(index+1)) > 0) {
                    E temp = array.get(index);
                    set(array, index, array.get(index+1));
                    set(array, index+1, temp);
                }
                index++;
            }
        }
    }

}