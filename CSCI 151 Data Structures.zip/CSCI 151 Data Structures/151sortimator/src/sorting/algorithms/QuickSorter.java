package sorting.algorithms;

import java.util.ArrayList;

public class QuickSorter<E extends Comparable<E>> extends Sorter<E> {

    @Override
    protected void sortAlgorithm(ArrayList<E> array) {
        quickSortHelper(array, 0, array.size() - 1);
    }

    protected ArrayList<E> quickSortHelper(ArrayList<E> array, int start, int end) {
        if (end - start > 1) {
            int mid = partition(array, start, end);
            quickSortHelper(array, start, mid);
            quickSortHelper(array, mid, end);
        }
        return array;
    }

    protected int partition(ArrayList<E> array, int start, int end) {
        E pivot = array.get(end);
        int smaller = 0;
        for (int i = start; i < end; i++) {
            if (array.get(i).compareTo(pivot) < 0) {
                E temp1 = array.get(i);
                E temp2 = array.get(start + smaller);
                array.set(start + smaller, temp1);
                array.set(i, temp2);
                smaller += 1;
            }
        }
        E temp = array.get(start + smaller);
        array.set(start + smaller, pivot);
        array.set(end, temp);
        return smaller;
    }
}
