package sorting.algorithms;

import sorting.ArrayQueue;

import java.util.ArrayList;

public class MergeSorter<E extends Comparable<E>> extends Sorter<E> {

    @Override
    protected void sortAlgorithm(ArrayList<E> array) {
        mergeSortHelper(array, 0, array.size());
    }

    protected ArrayList<E> mergeSortHelper(ArrayList<E> array, int start, int end) {
        if (end - start > 1) {
            int midpoint = (start + end) / 2;
            ArrayList<E> leftarray = mergeSortHelper(array, start, midpoint);
            ArrayList<E> rightarray = mergeSortHelper(array, midpoint, end);
        }
        ArrayList<E> finalarray = merge(array, start, end);
        return finalarray;
    }

    protected ArrayList<E> merge(ArrayList<E> array, int start, int end) {
        int midpoint = (int) (start + end) / 2;
        ArrayQueue<E> left = new ArrayQueue<>();
        ArrayQueue<E> right = new ArrayQueue<>();
        ArrayList<E> newarray = new ArrayList<>();
        if (start != midpoint) {
            for (int i = start; i < midpoint; i++) {
                left.add(array.get(i));
            }
            for (int i = midpoint; i < end; i++) {
                right.add(array.get(i));
            }
            for (int i = start; i < end; i++) {
                if (right.isEmpty() || (!left.isEmpty() && left.element().compareTo(right.element()) <= 0)) {
                    set(array, i, left.element());
                    left.remove();
                } else {
                    set(array, i, right.element());
                    right.remove();
                }
            }
            return newarray;
        }
        return array;
    }
}