package sorting.algorithms;

import java.util.ArrayList;

public class InsertionSorter<E extends Comparable<E>> extends Sorter<E> {

    @Override
    protected void sortAlgorithm(ArrayList<E> array) {
        int i = array.size() - 1;
        while (i > 0) {
            if (array.get(i).compareTo(array.get(i-1)) < 0) {
                E temp = array.get(i);
                set(array, i, array.get(i - 1));
                set(array, i - 1, temp);
                if (i != array.size() - 1) {
                    i = Math.max(0, i + 1);
                }
            } else {
                i -= 1;
            }
        }
    }

}