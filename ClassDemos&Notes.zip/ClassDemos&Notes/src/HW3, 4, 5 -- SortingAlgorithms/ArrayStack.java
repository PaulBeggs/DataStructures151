public class ArrayStack {
    private int[] stuff;
    private int top;

    public ArrayStack() {
        stuff = new int[2]; // Initial length of 2
        top = -1; // Initialize the stack as empty
    }

    public void push(int value) {
        if (top == stuff.length - 1) {
            // If the array is full, double its size
            int[] newStuff = new int[stuff.length * 2];
            System.arraycopy(stuff, 0, newStuff, 0, stuff.length);
            stuff = newStuff;
        }
        stuff[++top] = value;
    }

    public void pop() {
        if (top >= 0) {
            top--;
        }
    }

    public int peek() {
        if (top >= 0) {
            return stuff[top];
        }
        throw new IllegalStateException("Stack is empty.");
    }

    public boolean isEmpty() {
        return top == -1;
    }

    public int size() {
        return top + 1;
    }

    public static void main(String[] args) {
        ArrayStack s = new ArrayStack();

        s.push(2);
        s.push(3);
        s.push(5);
        s.push(8);
        s.pop();
        s.pop();
        s.push(1);
        System.out.println("Current stack elements:");
        for (int i = s.size() - 1; i >= 0; i--) {
            System.out.println(s.stuff[i]);
        }
    }
}
