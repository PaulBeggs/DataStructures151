import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        ArrayList<String> items = new ArrayList<>();
        String cmd = "";
        while (!cmd.equals("quit")) {
            System.out.print("> ");
            cmd = scan.nextLine();
            if (cmd.equals("help")) {
                System.out.println("Options");
                System.out.println("quit - Leave program");
                System.out.println("show - Display entire ArrayList");
                System.out.println("add [item] - Add item to ArrayList");
                System.out.println("find [item] - reveal whether an item is present");
            } else if (!cmd.equals("quit)")) {
                String[] parts = cmd.split(" ");
                if (parts[0].equals("show")) {
                    for (int i = 0; i < items.size(); i++) {
                        System.out.print(items.get(i) + " ");
                    }
                    System.out.println();
                } else if (parts[0].equals("add")) {
                    // to be "sorted" all indexes, i; arr[i] <= arr[i+1]
                    // for this instance, it would be better to write it as arr[i-1] <= arr[i]
                    items.add(parts[1]);
                    // for a condition to always be true for a data structure, we call that an invariant.
                    int i = items.size() - 1;
                    String temp = items.get(i);
                    while (i > 0 && items.get(i - 1).compareTo(items.get(i)) > 0) {
                        items.set(i, items.get(i - 1));
                        items.set(i - 1, temp);
                        i--;
                    }


                    /* example:
                     * add D -> i = 0; the loop does not initiate.
                     * add C -> i = 1; the loop initiates:
                     *   temp <- C
                     *   D is then moved into i=1, and C will be in 0.
                     * Add A -> i = 2; the loop initiates:
                     *   temp <- A
                     *   A is then moved into i=2, and D will be moved to items.size() [which will -
                     *   - give 2. Note that .size() will give the length of the array, and then D will -
                     *   - be moved to the newly established end]. From there,
                     *   temp <- A
                     *   A is then moved into i=1, and C will be moved into items.set(i, items.get(i-1))
                     * */

                } else if (parts[0].equals("find")) {
                    if (binarySearch(parts[1], items)) {

                    }
                }
            }
        }
    }

    public static boolean binarySearch(String value, ArrayList<String> items) {
        int min = 0;
        int max = items.size() - 1;
        while (min <= max) {
            int mid = (min + max) / 2;
            int comparison = items.get(mid).compareTo(value);
            if (comparison < 0) {
                min = mid + 1;
            } else if (comparison > 0) {
                max = mid - 1;
            }
        }
        return false;
    }
}