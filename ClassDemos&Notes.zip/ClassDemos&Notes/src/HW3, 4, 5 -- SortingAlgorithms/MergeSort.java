public class MergeSort {
    public static void main(String[] args) {
        int[] array = {12, 11, 13, 5, 6, 7};
        System.out.println("Original Array:");
        printArray(array);

        mergeSort(array);

        System.out.println("\nSorted Array:");
        printArray(array);
    }

    public static void mergeSort(int[] array) {
        if (array.length > 1) {
            int mid = array.length / 2;
            int[] leftHalf = new int[mid];
            int[] rightHalf = new int[array.length - mid];

            for (int i = 0; i < mid; i++) {
                leftHalf[i] = array[i];
            }

            for (int i = mid; i < array.length; i++) {
                rightHalf[i - mid] = array[i];
            }

            mergeSort(leftHalf);
            mergeSort(rightHalf);

            merge(array, leftHalf, rightHalf);
        }
    }

    public static void merge(int[] array, int[] leftHalf, int[] rightHalf) {
        int i = 0, j = 0, k = 0;

        while (i < leftHalf.length && j < rightHalf.length) {
            if (leftHalf[i] <= rightHalf[j]) {
                array[k++] = leftHalf[i++];
            } else {
                array[k++] = rightHalf[j++];
            }
        }

        while (i < leftHalf.length) {
            array[k++] = leftHalf[i++];
        }

        while (j < rightHalf.length) {
            array[k++] = rightHalf[j++];
        }
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
