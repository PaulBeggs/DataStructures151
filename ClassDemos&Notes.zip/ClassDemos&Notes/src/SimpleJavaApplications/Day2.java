package SimpleJavaApplications;

import java.io.PrintStream;

public class Day2 {
    public Day2() {
    }

    public static void main(String[] args) {
        System.out.println("true, false");
        System.out.println("any spaces? " + anySpaces("this is a test"));
        System.out.println("any spaces? " + anySpaces("testing"));
        System.out.println("true, false");
        System.out.println("any digits? " + anyDigits("this is the 1"));
        System.out.println("any digits? " + anyDigits("this is the one"));
        System.out.println("false, true");
        System.out.println("all digits? " + allDigits("123 four 5"));
        System.out.println("all digits? " + allDigits("12345"));
        System.out.println("Without spaces: " + withoutSpaces("this is a test"));
        System.out.println("Encoding 'hello': " + encrypt("hello", 2));
        int[] nums = new int[]{5, 3, 1, 2, 4, 6, 7, 8, 0};
        System.out.println("number of elements: " + nums.length);
        System.out.println("nums: " + showNums(nums));
        int max = findMax(nums);
        int min = findMin(nums);
        System.out.println("Maximum value: " + max);
        System.out.println("Minimum value: " + min);
        int sum = sumArray(nums);
        System.out.println("Sum of all elements: " + sum);
        int[] copiedArray = copyArray(nums);
        System.out.println("Copied Array: " + showNums(copiedArray));
        int[] reversedArray = reverseArray(nums);
        System.out.println("Reversed Array: " + showNums(reversedArray));
        int target = 4;
        boolean containsTarget = contains(nums, target);
        System.out.println("Array contains " + target + ": " + containsTarget);
        int addend = 2;
        int[] addedArray = addToAll(nums, addend);
        System.out.println("Added " + addend + " to all elements: " + showNums(addedArray));
        addInPlace(nums, 3);
        System.out.println("After adding 3 in place: " + showNums(nums));
        int[] a = new int[]{1, 2, 3};
        int[] b = new int[]{1, 3};
        int[] c = new int[]{7, 2, 3};
        int[] d = new int[]{1};
        int[] e = new int[]{1, 2};
        int[] f = new int[0];
        PrintStream var10000 = System.out;
        int var10001 = start1(a, b);
        var10000.println("start1([1, 2, 3], [1, 3]) → " + var10001);
        var10000 = System.out;
        var10001 = start1(c, d);
        var10000.println("start1([7, 2, 3], [1]) → " + var10001);
        var10000 = System.out;
        var10001 = start1(e, f);
        var10000.println("start1([1, 2], []) → " + var10001);
        int[] array1 = new int[]{1, 2};
        int[] array2 = new int[]{4, 5};
        int[] sumArray = addArrays(array1, array2);
        System.out.println("Sum of arrays: " + showNums(sumArray));
    }

    public static String showNums(int[] numbers) {
        String result = "";

        for(int i = 0; i < numbers.length; ++i) {
            result = result + numbers[i] + " ";
        }

        return result;
    }

    public static int[] addToAll(int[] numbers, int addend) {
        int[] result = new int[numbers.length];

        for(int i = 0; i < numbers.length; ++i) {
            result[i] = numbers[i] + addend;
        }

        return result;
    }

    public static void addInPlace(int[] numbers, int addend) {
        for(int i = 0; i < numbers.length; ++i) {
            numbers[i] += addend;
        }

    }

    public static int findMax(int[] numbers) {
        int max = numbers[0];

        for(int i = 1; i < numbers.length; ++i) {
            if (numbers[i] > max) {
                max = numbers[i];
            }
        }

        return max;
    }

    public static int findMin(int[] numbers) {
        int min = numbers[0];

        for(int i = 1; i < numbers.length; ++i) {
            if (numbers[i] < min) {
                min = numbers[i];
            }
        }

        return min;
    }

    public static int sumArray(int[] numbers) {
        int sum = 0;

        for(int i = 0; i < numbers.length; ++i) {
            int num = numbers[i];
            sum += num;
        }

        return sum;
    }

    public static int[] copyArray(int[] original) {
        int[] copy = new int[original.length];

        for(int i = 0; i < original.length; ++i) {
            copy[i] = original[i];
        }

        return copy;
    }

    public static int[] reverseArray(int[] numbers) {
        int[] reversed = new int[numbers.length];

        for(int i = 0; i < numbers.length; ++i) {
            reversed[numbers.length - 1 - i] = numbers[i];
        }

        return reversed;
    }

    public static int start1(int[] a, int[] b) {
        int countA = 0;
        int countB = 0;
        if (a.length > 0 && a[0] == 1) {
            countA = 1;
        }

        if (b.length > 0 && b[0] == 1) {
            countB = 1;
        }

        return countA + countB;
    }

    public static int[] addArrays(int[] arr1, int[] arr2) {
        if (arr1.length == 2 && arr2.length == 2) {
            int[] result = new int[]{arr1[0] + arr2[0], arr1[1] + arr2[1]};
            return result;
        } else {
            throw new IllegalArgumentException("Arrays must have a length of 2 for element-wise addition.");
        }
    }

    public static boolean contains(int[] numbers, int target) {
        int[] var2 = numbers;
        int var3 = numbers.length;

        for(int var4 = 0; var4 < var3; ++var4) {
            int num = var2[var4];
            if (num == target) {
                return true;
            }
        }

        return false;
    }

    public static boolean anyNewlines(String s) {
        for(int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) == '\n') {
                return true;
            }
        }

        return false;
    }

    public static boolean anySpaces(String s) {
        for(int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) == ' ') {
                return true;
            }
        }

        return false;
    }

    public static String encrypt(String s, int offset) {
        String result = "";

        for(int i = 0; i < s.length(); ++i) {
            result = result + (char)(s.charAt(i) + offset);
        }

        return result;
    }

    public static String withoutSpaces(String s) {
        String result = "";

        for(int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) != ' ') {
                result = result + s.charAt(i);
            }
        }

        return result;
    }

    public static boolean anyDigits(String s) {
        for(int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) >= '0' && s.charAt(i) <= '9') {
                return true;
            }
        }

        return false;
    }

    public static boolean allDigits(String s) {
        for(int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) < '0' || s.charAt(i) > '9') {
                return false;
            }
        }

        return true;
    }
}