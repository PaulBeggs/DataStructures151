package SimpleJavaApplications;

public class Main {
    public Main() {
    }

    public static void main(String[] args) {
        int x = 4;
        System.out.println("Two plus two equals " + x);
    }
}