package SimpleJavaApplications;

public class Day1 {
    public Day1() {
    }

    public static void main(String[] args) {
        System.out.println("3**4 =     " + power(3, 4));
        System.out.println("recursive: " + power2(3, 4));
        System.out.println("for:       " + power3(3, 4));
        System.out.println("while:     " + power4(3, 4));
        System.out.println(repeat("lunch", 4));
        System.out.println(repeat2("lunch", 4));
        System.out.println(count("aardvark", 'a'));
    }

    public static int count(String s, char c) {
        int result = 0;

        for(int i = 0; i < s.length(); ++i) {
            if (s.charAt(i) == c) {
                ++result;
            }
        }

        return result;
    }

    public static String repeat(String s, int repetitions) {
        return repetitions == 0 ? "" : s + repeat(s, repetitions - 1);
    }

    public static int power2(int base, int exponent) {
        return exponent == 0 ? 1 : base * power2(base, exponent - 1);
    }

    public static int power(int base, int exponent) {
        int result;
        for(result = 1; exponent > 0; --exponent) {
            result *= base;
        }

        return result;
    }

    public static int power3(int base, int exponent) {
        int result = 1;

        for(int i = 0; i < exponent; ++i) {
            result *= base;
        }

        return result;
    }

    public static String repeat2(String s, int repetitions) {
        String result = "";

        for(int i = 0; i < repetitions; ++i) {
            result = result + s;
        }

        return result;
    }

    public static int power4(int base, int exponent) {
        int result = 1;

        for(int i = 0; i < exponent; ++i) {
            result *= base;
        }

        return result;
    }
}