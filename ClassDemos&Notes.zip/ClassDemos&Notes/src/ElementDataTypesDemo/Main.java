import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter a string: ");
        String input = scan.nextLine();
        Pair<String> pair = splitInTwo(input);
        System.out.println(pair.getFirst());
        System.out.println(pair.getSecond());

        System.out.println("Enter two ints, separated by a space: ");
        Pair<Integer> intPair = coordinatesFrom(scan.nextLine());
        System.out.println(intPair.getFirst());
        System.out.println(intPair.getSecond());
        System.out.println("Sum: " + intPair.getFirst() + intPair.getSecond());

        System.out.println("Enter a String and int, separated by a space");
    }


    public static Pair<String> splitInTwo(String s) {
        String firstHalf = s.substring(0, s.length() / 2);
        String secondHalf =s.substring(s.length() / 2);
        return new Pair<>(firstHalf, secondHalf); // In the braces, we used to have "String"
        // But now we can change the braces to empty. This is known as a Type inference.
    }

    public static Pair<Integer> coordinatesFrom(String s) {
        String[] parts = s.split(" ");
        int firstPart = Integer.parseInt(parts[0]);
        int secondPart = Integer.parseInt(parts[1]);
        return new Pair<>(firstPart, secondPart);
    }

//    public static MixedPair<String,Integer> labeledIntfrom(String s) {
//        String[] parts = s.split(" ");
//        int intPart = Integer.parseInt
//    }
}