public class MixedPair<F,S> {
    // Must use single capital letters for Type Variables.
    private F first;
    private S second;

    // F and S is a "generic data type."

//    public pair(F first, S second) {
//        this.first = first;
//        this.second = second;

    public F getFirst() {
        return first;
    }
    public S getSecond() {
        return second;
    }
}
