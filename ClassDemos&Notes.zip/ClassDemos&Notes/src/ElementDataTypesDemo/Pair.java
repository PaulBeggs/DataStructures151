public class Pair<T> {
    private T first;
    private T second;

    // T is a "generic data type."
    // T is also known as a "Type variable"

    public Pair(T first, T second) {
        this.first = first;
        this.second = second;
    }
    public T getFirst() {
        return first;
    }
    public T getSecond() {
        return second;
    }
}