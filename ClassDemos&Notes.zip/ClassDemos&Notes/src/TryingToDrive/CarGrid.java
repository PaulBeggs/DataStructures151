package TryingToDrive;

import TryingToDrive.Car;

public class  CarGrid {
    private boolean[][] carWasAt;

    public CarGrid(int width, int height) {
        carWasAt = new boolean[height][width];
    }

    public void logCarAt(Car c) {
        int row = (int)c.getY();
        int col = (int)c.getX();
        if (row >= 0 && row < carWasAt.length && col >= 0 && col < carWasAt[row].length) {
            carWasAt[row][col] = true;
        }
    }

    @Override
    public String toString() {
        String result = "";
        for (int row = 0; row < carWasAt.length; row++) {
            for (int col = 0; col < carWasAt[row].length; col++) {
                if (carWasAt[row][col]) {
                    result += '@';
                } else {
                    result += '.';
                }
            }
            result += '\n';
        }
        return result;
    }
}
