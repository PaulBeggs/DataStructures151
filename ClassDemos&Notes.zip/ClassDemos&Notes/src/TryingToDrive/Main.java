package TryingToDrive;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double mpg = inputDouble(scan, "MPG?");
        double fuelCapacity = inputDouble(scan, "Tank size?");
        double idleFuelPerMinute = inputDouble(scan, "Idling/minute?");
        Car c = new Car(mpg, fuelCapacity, idleFuelPerMinute);
        System.out.println(c);
        int logEntries = inputInt(scan, "# log entries: ");
        DrivingTranscript script = new DrivingTranscript(logEntries);
        for (int i = 0; i < logEntries; i++) {
            double drove = inputDouble(scan, "Distance? ");
            double idle = inputDouble(scan, "Idle? ");
            script.log(drove, idle);
        }
        if (c.canComplete(script)) {
            c.driveScript(script);
            System.out.println(c);
        } else {
            System.out.println("Sorry, can't drive that journey.");
        }
    }
    public static double inputDouble(Scanner scan, String prompt) {
        System.out.print(prompt + " ");
        return Double.parseDouble(scan.nextLine());
    }
    public static int inputInt(Scanner scan, String prompt) {
        System.out.print(prompt + " ");
        return Integer.parseInt(scan.nextLine());
    }
    public static void tryDriving(Car c, double distance) {
        if (c.canDrive(distance)) {
            c.drive(distance);
            System.out.println(c);
        } else {
            System.out.println("Not enough fuel to drive " + distance + " miles");
        }
    }
}
