package TryingToDrive;

public class Car {
    private double fuelCapacity;
    private double fuelLeft;
    private double milesPerGallon;
    private double idleFuelPerMinute;
    private double milesTraveled = 0.0;
    private double x = 0.0;
    private double y = 0.0;
    private double heading = 0.0;

    public Car(double milesPerGallon, double fuelCapacity, double idleFuelPerMinute) {
        this.fuelCapacity = fuelCapacity;
        this.fuelLeft = fuelCapacity;
        this.milesPerGallon = milesPerGallon;
        this.idleFuelPerMinute = idleFuelPerMinute;
    }

    public double tankSpace() {
        return fuelCapacity - fuelLeft;
    }

    public void fillUp() {
        fuelLeft = fuelCapacity;
    }

    public double fuelNeeded(double distance) {
        return distance / milesPerGallon;
    }

    public double fuelNeededFor(DrivingTranscript script) {
        return fuelNeeded(script.totalDistance()) + script.totalIdleTime() * idleFuelPerMinute;
    }

    public boolean canDrive(double distance) {
        return fuelNeeded(distance) < fuelLeft;
    }

    public boolean canComplete(DrivingTranscript script) {
        return fuelNeededFor(script) < fuelLeft;
    }

    public void drive(double distance) {
        fuelLeft -= fuelNeeded(distance);
        milesTraveled += distance;
        x += distance * Math.cos(heading);
        y += distance * Math.sin(heading);
    }

    public void turn(double angle) {
        heading += angle;
    }

    public void driveScript(DrivingTranscript script) {
        fuelLeft -= fuelNeededFor(script);
        milesTraveled += script.totalDistance();
    }

    public double getX() {return x;}
    public double getY() {return y;}

    @Override
    public String toString() {
        return "Fuel: " + fuelLeft + "/" + fuelCapacity + " MPG: "
                + milesPerGallon + " odometer: " + milesTraveled +
                " location: (" + x + "," + y + ")";
    }
}

