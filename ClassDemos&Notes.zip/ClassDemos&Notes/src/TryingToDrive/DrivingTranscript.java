package TryingToDrive;

public class DrivingTranscript {
    private double[] driveDistances;
    private double[] idleWaitTimes;
    private int nextIndex = 0;

    public DrivingTranscript(int maxRecords) {
        driveDistances = new double[maxRecords];
        idleWaitTimes = new double[maxRecords];
    }

    public void log(double distance, double idleTime) {
        driveDistances[nextIndex] = distance;
        idleWaitTimes[nextIndex] = idleTime;
        nextIndex++;
    }

    public static double arraySum(double[] nums) {
        double result = 0.0;
        for (int i = 0; i < nums.length; i++) {
            result += nums[i];
        }
        return result;
    }

    public double totalDistance() {
        return arraySum(driveDistances);
    }

    public double totalIdleTime() {
        return arraySum(idleWaitTimes);
    }
}
