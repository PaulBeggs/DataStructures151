package TryingToDrive;

import java.util.Scanner;

public class DriveWithTurns {
    static final double DRIVE_DISTANCE = 1.0;
    static final double RIGHT_ANGLE = Math.PI / 2;

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        double mpg = Main.inputDouble(scan, "MPG?");
        double fuelCapacity = Main.inputDouble(scan, "Tank size?");
        double idleFuelPerMinute = Main.inputDouble(scan, "Idling/minute?");

        Car c = new Car(mpg, fuelCapacity, idleFuelPerMinute);
        System.out.println(c);

        CarGrid grid = new CarGrid(80, 40);

        while (c.canDrive(DRIVE_DISTANCE)) {
            System.out.print("Drive, Left, or Right? ");
            String cmd = scan.nextLine();
            if (cmd.equals("Drive")) {
                c.drive(DRIVE_DISTANCE);
            } else if (cmd.equals("Left")) {
                c.turn(-RIGHT_ANGLE);
            } else if (cmd.equals("Right")) {
                c.turn(RIGHT_ANGLE);
            } else {
                System.out.println("I don't understand your command '" + cmd + "'.");
            }
            System.out.println(c);
            grid.logCarAt(c);
        }
        System.out.println(grid);
    }
}
