package WarehouseDemo;

public enum Direction {
    NORTH {
        @Override
        public int nextRow(int row) {
            return row - 1;
        }
    },
    SOUTH {
        @Override
        public int nextRow(int row) {
            return row + 1;
        }
    },
    EAST {
        @Override
        public int nextCol(int col) {
            return col + 1;
        }
    },
    WEST {
        @Override
        public int nextCol(int col) {
            return col - 1;
        }
    };

    public int nextCol(int col) {
        return col;
    }

    public int nextRow(int row) {
        return row;
    }

    public static Direction fromString(String s) {
        if (s.startsWith("N")) {
            return Direction.NORTH;
        } else if (s.startsWith("S")) {
            return Direction.SOUTH;
        } else if (s.startsWith("E")) {
            return Direction.EAST;
        } else if (s.startsWith("W")) {
            return Direction.WEST;
        } else {
            throw new IllegalArgumentException(s + " is not a valid Direction");
        }
    }
}

