package WarehouseDemo;

public enum WarehouseObject {
    SPACE {
        @Override
        public String toString() {
            return ".";
        }
    },
    WALL {
        @Override
        public String toString() {
            return "#";
        }
    },
    BOX {
        @Override
        public String toString() {
            return "O";
        }

        @Override
        public boolean pushable() {
            return true;
        }
    },
    WORKER {
        @Override
        public String toString() {
            return "I";
        }

        @Override
        public boolean canPush() {
            return true;
        }
    };

    @Override
    abstract public String toString();

    public boolean canPush() {
        return false;
    }

    public boolean pushable() {
        return false;
    }

    public static WarehouseObject fromString(String s) {
        if (s.equals("Wall")) {
            return WarehouseObject.WALL;
        } else if (s.equals("Space")) {
            return WarehouseObject.SPACE;
        } else if (s.equals("Worker")) {
            return WarehouseObject.WORKER;
        } else if (s.equals("Box")) {
            return WarehouseObject.BOX;
        } else {
            throw new IllegalArgumentException(s + " is not a WarehouseObject");
        }
    }
}
