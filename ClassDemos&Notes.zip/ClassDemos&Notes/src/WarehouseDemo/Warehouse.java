package WarehouseDemo;

public class Warehouse {
    private WarehouseObject[][] floor;

    public Warehouse(int height, int width) {
        floor = new WarehouseObject[height][width];
        for (int col = 0; col < floor[0].length; col++) {
            floor[0][col] = WarehouseObject.WALL;
            floor[floor.length - 1][col] = WarehouseObject.WALL;
        }

        for (int row = 0; row < floor.length; row++) {
            floor[row][0] = WarehouseObject.WALL;
            floor[row][floor[row].length - 1] = WarehouseObject.WALL;
        }

        for (int row = 1; row < floor.length - 1; row++) {
            for (int col = 1; col < floor[row].length - 1; col++) {
                floor[row][col] = WarehouseObject.SPACE;
            }
        }
    }

    public void add(WarehouseObject obj, int row, int col) {
        floor[row][col] = obj;
    }

    public void push(int row, int col, Direction d) {
        if (floor[row][col].canPush()) {
            int newRow = d.nextRow(row);
            int newCol = d.nextCol(col);
            if (floor[newRow][newCol].pushable()) {
                int finalRow = d.nextRow(newRow);
                int finalCol = d.nextCol(newCol);
                floor[finalRow][finalCol] = floor[newRow][newCol];
                floor[newRow][newCol] = floor[row][col];
                floor[row][col] = WarehouseObject.SPACE;
            }
        }
    }

    @Override
    public String toString() {
        String result = "";
        for (int row = 0; row < floor.length; row++) {
            for (int col = 0; col < floor[row].length; col++) {
                result += floor[row][col].toString();
            }
            result += "\n";
        }
        return result;
    }
}


