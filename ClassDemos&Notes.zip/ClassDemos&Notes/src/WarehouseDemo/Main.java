package WarehouseDemo;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Warehouse w = new Warehouse(4, 8);
        System.out.println(w);

        Scanner scan = new Scanner(System.in);
        String request = getRequest(scan);
        while (!request.equals("QUIT")) {
            if (request.startsWith("ADD")) {
                String[] cmd = request.split(" ");
                int row = Integer.parseInt(cmd[2]);
                int col = Integer.parseInt(cmd[3]);
                w.add(WarehouseObject.fromString(cmd[1]), row, col);
            } else if (request.startsWith("PUSH")) {
                String[] cmd = request.split(" ");
                int row = Integer.parseInt(cmd[1]);
                int col = Integer.parseInt(cmd[2]);
                Direction d = Direction.fromString(cmd[3]);
                w.push(row, col, d);
            }
            System.out.println(w);
            request = getRequest(scan);
        }
    }

    public static String getRequest(Scanner scan) {
        System.out.println("Options: ");
        System.out.println("ADD (Wall | Space | Box | Worker) [row] [col]");
        System.out.println("PUSH [row] [col] (N | S | E | W)");
        System.out.println("QUIT");
        System.out.print("> ");
        return scan.nextLine();
    }
}