package TriesDemo;

public class Tries {
}
