package matrix.model;

import javafx.scene.control.TextField;

import java.util.List;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class MatrixView {
    private Matrix matrix;
    private GridPane gridPane;

    public MatrixView(Matrix matrix, GridPane gridPane) {
        this.matrix = matrix;
        this.gridPane = gridPane;
    }

    public void displayOnGridPane() {
        gridPane.getChildren().clear();

        int numRows = matrix.getRows();
        int numCols = matrix.getCols();

        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                TextField cell = new TextField(String.valueOf(matrix.getValue(row, col)));
                cell.setMinHeight(50);
                cell.setMinWidth(50);
                cell.setAlignment(javafx.geometry.Pos.CENTER);
                cell.setEditable(true);

                gridPane.add(cell, col, row);
            }
        }
    }

    public Matrix getMatrix() {
        return matrix;
    }

    public void update() {

    }
}