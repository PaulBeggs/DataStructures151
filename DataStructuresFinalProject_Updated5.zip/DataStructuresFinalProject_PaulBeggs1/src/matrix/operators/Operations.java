package matrix.operators;

public interface Operations {
    boolean isValidRow(int row);
    boolean isValidCol(int col);
}
