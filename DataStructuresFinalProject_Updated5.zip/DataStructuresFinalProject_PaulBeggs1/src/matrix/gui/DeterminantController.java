package matrix.gui;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.operators.MatrixDeterminantOperations;

import java.io.IOException;
import java.text.DecimalFormat;

public class DeterminantController implements DataManipulation {

    DecimalFormat decimalFormat = new DecimalFormat("#.##");
    @FXML
    Button saveButton;
    @FXML
    Button loadButton;
    @FXML
    TextField multiplier;
    @FXML
    TextField targetRow;
    @FXML
    Button compute;
    @FXML
    ChoiceBox<Scenes> scenes;

    @FXML
    private void initialize() {
        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.DETERMINANT);

        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    @FXML
    public void handleDeterminantFunctionality() {
        Matrix matrix = MatrixFileHandler.getMatrix("main_scene_matrix");
        System.out.println("2nd Matrix: \n" + matrix + "\n");

        if (matrix != null) {
            // Perform determinant calculation
            MatrixDeterminantOperations determinantOperations = new MatrixDeterminantOperations(matrix);
            double determinant = determinantOperations.calculateDeterminant();

            // Display or use the determinant as needed
            System.out.println("Determinant: " + decimalFormat.format(determinant));
        } else {
            System.out.println("Matrix not found. Generate a matrix first.");
        }
    }

    @Override
    public void handleSaveButton() {

    }

    @Override
    public void handleLoadButton() {

    }

    @Override
    public void update() {

    }
}

