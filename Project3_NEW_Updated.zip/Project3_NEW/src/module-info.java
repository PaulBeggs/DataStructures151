module Block {
    requires javafx.fxml;
    requires javafx.controls;
    exports block;
    opens block;
}