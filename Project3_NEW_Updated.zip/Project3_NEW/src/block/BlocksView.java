package block;

import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.function.Consumer;

public class BlocksView extends Parent {

    private Block block;
    private Rectangle r;

    public BlocksView(Block block, Consumer<BlocksView> removeBlockHandler) {
        this.block = block;

        r = new Rectangle(50, 50);
        r.setFill(Color.RED);
        r.setStroke(Color.BLACK);
        r.setOnMousePressed(event -> pressed(event, block));
        r.setOnMouseReleased(event -> released(event, block, removeBlockHandler));
        getChildren().add(r);
    }

    public Block getBlock() {
        return block;
    }

    // What to do when the mouse is Pressed
    private void pressed(MouseEvent event, Block b) {
        b.toggleMovement();
        r.setFill(Color.WHITESMOKE);
        event.consume();
    }

    // What to do when the mouse is Released
    private void released(MouseEvent event, Block b, Consumer<BlocksView> removeBlockHandler) {
        b.toggleMovement();
        r.setFill(Color.RED);
        removeBlockHandler.accept(this);
    }

    public void update() {
        r.setArcHeight(block.getLength());
        r.setArcWidth(block.getLength());
        r.setTranslateX(block.getX());
        r.setTranslateY(block.getY());
    }
}
