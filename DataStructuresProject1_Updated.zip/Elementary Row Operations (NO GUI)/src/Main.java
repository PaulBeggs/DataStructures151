import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        MatrixInputHandler inputHandler = new MatrixInputHandler(scanner);

        int numRows = inputHandler.getPositiveIntInput("Enter the number of rows: ");
        int numCols = inputHandler.getPositiveIntInput("Enter the number of columns: ");

        Matrix matrix = new Matrix(numRows, numCols);
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                System.out.print("Enter value for row " + (row + 1) + ", column " + (col + 1) + ": ");
                matrix.set(row, col, scanner.nextDouble());
            }
        }
        System.out.println("\n");
        System.out.println("Matrix:");
        System.out.println(matrix);

        String operationSummary = "Order of Operations:\n";

        int operationCount = 0;
        boolean exit = false;
        while (!exit) {

            operationCount++;
            System.out.println("Choose an operation:");
            System.out.println("1. Swap rows");
            System.out.println("2. Multiply row by scalar");
            System.out.println("3. Add one row to another");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");

            int choice = inputHandler.getChoice("Choose an operation (1, 2, 3, or 4): ", 1, 4);

            if (choice == 1) {

                System.out.print("Enter the first row to swap: ");
                int row1 = scanner.nextInt() - 1;
                System.out.print("Enter the second row to swap: ");
                int row2 = scanner.nextInt() - 1;
                matrix.swapRows(row1, row2);
                operationSummary += operationCount + ". Swapped Rows " + (row1 + 1) + " and " + (row2 + 1) + ".\n";

            } else if (choice == 2) {

                System.out.print("Enter the row to be multiplied: ");
                int multipliedRow = scanner.nextInt() - 1;
                System.out.print("Enter the multiplier: ");
                double multiplier = scanner.nextDouble();
                RowMultiplication.multiplyRow(matrix, multipliedRow, multiplier);
                operationSummary += operationCount + ". Multiplied Row " + (multipliedRow + 1) + " by " + multiplier + ".\n";

            } else if (choice == 3) {

                System.out.print("Enter the row to be multiplied and added: ");
                int multipliedRow = scanner.nextInt() - 1;
                System.out.print("Enter the target row: ");
                int targetRow = scanner.nextInt() - 1;
                System.out.print("Enter the multiplier for the source row: ");
                double multiplier = scanner.nextDouble();
                RowAddition.addRows(matrix, multipliedRow, targetRow, multiplier);
                operationSummary += operationCount + ". Multiplied Row " + (multipliedRow + 1) + " by " + multiplier + ", and added it to Row " + (targetRow + 1) + ".\n";

            } else if (choice == 4) {
                exit = true;
            }

            System.out.println("Updated matrix:");
            System.out.println(matrix);
        }
        System.out.println("\n");
        System.out.println(operationSummary);

        scanner.close();
    }

    public static void printMatrix(double[][] matrix) {
        int numRows = matrix.length;
        int numCols = matrix[0].length;

        System.out.println("Rows: " + numRows);
        System.out.println("Columns: " + numCols);

        for (int row = 0; row < numRows; row++) {
            System.out.print("| ");
            for (int col = 0; col < numCols; col++) {
                System.out.print(matrix[row][col] + " ");
            }
            System.out.println("|");
        }
    }
}