public class Matrix {
    private double[][] matrix;

    public Matrix(int numRows, int numCols) {
        matrix = new double[numRows][numCols];
    }

    public void set(int row, int col, double value) {
        matrix[row][col] = value;
    }

    public int getRows() {
        return matrix.length;
    }

    public int getCols() {
        return matrix[0].length;
    }

    public void swapRows(int row1, int row2) {
        double[] temp = matrix[row1];
        matrix[row1] = matrix[row2];
        matrix[row2] = temp;
    }

    public String toString() {
        String result = "";
        result += "Rows: " + getRows() + "\n";
        result += "Columns " + getCols() + "\n";

        for (int row = 0; row < getRows(); row++) {
            result += "| ";
            for (int col = 0; col < getCols(); col++) {
                result += matrix[row][col] + " ";
            }
            result += "| \n";
        }

        return result;
    }
}
