import java.util.Scanner;

public class MatrixInputHandler {
    private Scanner scanner;

    public MatrixInputHandler(Scanner scanner) {
        this.scanner = scanner;
    }

    public int getPositiveIntInput(String prompt) {
        int input = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
                if (input > 0) {
                    validInput = true;
                } else {
                    System.out.println("Input must be greater than 0. Please try again.");
                }
            } else {
                System.out.println("Invalid input. Please enter a positive integer.");
                scanner.next();
            }
        }
        return input;
    }

    public int getChoice(String prompt, int minChoice, int maxChoice) {
        int choice = 0;
        boolean validChoice = false;
        while (!validChoice) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                if (choice >= minChoice && choice <= maxChoice) {
                    validChoice = true;
                } else {
                    System.out.println("Invalid choice. Please choose a valid option.");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid option.");
                scanner.next();
            }
        }
        return choice;
    }
}