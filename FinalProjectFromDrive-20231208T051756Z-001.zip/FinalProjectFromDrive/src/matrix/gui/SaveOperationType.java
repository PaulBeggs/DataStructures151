package matrix.gui;

public enum SaveOperationType {
    MATRIX_ONLY,
    MATRIX_AND_DETERMINANT;
}
