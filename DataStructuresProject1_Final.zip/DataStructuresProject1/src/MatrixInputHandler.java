import java.util.Scanner;

public class MatrixInputHandler {
    private Scanner scanner;

    public MatrixInputHandler(Scanner scanner) {
        this.scanner = scanner;
    }

    public int getPositiveIntInput(String prompt) {
        int input = 0;
        boolean validInput = false;
        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                input = scanner.nextInt();
                if (input > 0) {
                    validInput = true;
                } else {
                    System.out.println("Input must be greater than 0. Please try again. \n");
                }
            } else {
                System.out.println("Invalid input. Please enter a positive integer. \n");
                scanner.next();
            }
        }
        return input;
    }

    public double getDoubleInput(String prompt) {
        double input = 0.0;
        boolean validInput = false;
        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextDouble()) {
                input = scanner.nextDouble();
                validInput = true;
            } else {
                System.out.println("Invalid input. Please enter a valid double. \n");
                scanner.next();
            }
        }
        return input;
    }

    public int getChoice(String prompt, int maxChoice) {
        int choice = 0;
        boolean validChoice = false;
        while (!validChoice) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                if (choice >= 1 && choice <= maxChoice) {
                    validChoice = true;
                } else {
                    System.out.println("Invalid choice. Please choose a valid option. \n");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid option. \n");
                scanner.next();
            }
        }
        return choice;
    }

    public int getValidRow(String prompt, int numRows) {
        int row = -1;
        boolean validInput = false;

        while (!validInput) {
            System.out.print(prompt);
            if (scanner.hasNextInt()) {
                row = scanner.nextInt() - 1;
                if (row >= 0 && row < numRows) {
                    validInput = true;
                } else {
                    System.out.println("Invalid row selection. Please choose a valid row. \n");
                }
            } else {
                System.out.println("Invalid input. Please enter a valid integer. \n");
                scanner.next();
            }
        }

        return row;
    }
}
