import java.util.Scanner;

public class Matrix {
    private double[][] matrix;
    private final Scanner scanner;
    private MatrixInputHandler inputHandler;


    public Matrix(int numRows, int numCols, Scanner scanner) {
        this.scanner = scanner;
        this.inputHandler =new MatrixInputHandler(scanner);
        initializeMatrixColumnsAndRows(numRows, numCols);
    }

    public void initializeMatrixColumnsAndRows(int numRows, int numCols) {
        matrix = new double[numRows][numCols];
        setMatrixValues();
    }

    public void set(int row, int col, double value) {
        if (isValidRow(row) && isValidColumn(col)) {
            matrix[row][col] = value;
        }
    }

    public void setMatrixValues() {
        System.out.println("Enter the initial values for the matrix:");

        for (int row = 0; row < getRows(); row++) {
            for (int col = 0; col < getCols(); col++) {
                System.out.print("Enter value for row " + (row + 1) + ", column " + (col + 1) + ": ");
                double value = scanner.nextDouble();
                set(row, col, value);
            }
        }
    }

    public int getRows() {
        return matrix.length;
    }

    public int getCols() {
        return matrix[0].length;
    }

    public void swapRows(int row1, int row2) {
        if (isValidRow(row1) && isValidRow(row2)) {
            double[] temp = matrix[row1];
            matrix[row1] = matrix[row2];
            matrix[row2] = temp;
        }
    }
    public void multiplyRow(int row, double multiplier) {
        if (isValidRow(row)) {
            for (int col = 0; col < getCols(); col++) {
                matrix[row][col] *= multiplier;
            }
        }
    }

    public void addRows(int sourceRow, int targetRow, double multiplier) {
        if (isValidRow(sourceRow) && isValidRow(targetRow)) {
            for (int col = 0; col < getCols(); col++) {
                matrix[targetRow][col] += multiplier * matrix[sourceRow][col];
            }
        }
    }

    public static String performMatrixOperations(Matrix matrix) {
        boolean exit = false;
        String operationSummary = "Order of Operations:\n";
        int operationCount = 0;

        while (!exit) {
            operationCount++;

            int choice = matrix.inputHandler.getChoice("""
                    Choose an operation:
                    1. Swap rows
                    2. Multiply row by scalar
                    3. Add one row to another
                    4. Exit
                    Enter your choice:\s""", 4);

            if (choice == 1) {
                int row1 = matrix.inputHandler.getValidRow("Enter the first row to swap: ", matrix.getRows());
                int row2 = matrix.inputHandler.getValidRow("Enter the second row to swap: ", matrix.getRows());
                if (row1 != row2) {
                    matrix.swapRows(row1, row2);
                    operationSummary += operationCount + ". Swapped Rows " + (row1 + 1) + " and " + (row2 + 1) + ".\n";
                } else {
                    System.out.println("Rows are the same. No action performed.\n");
                }
            } else if (choice == 2) {
                int row = matrix.inputHandler.getValidRow("Enter the row to be multiplied: ", matrix.getRows());
                double multiplier = matrix.inputHandler.getDoubleInput("Enter the multiplier: ");
                matrix.multiplyRow(row, multiplier);
                operationSummary += operationCount + ". Multiplied Row " + (row + 1) + " by " + multiplier + ".\n";
            } else if (choice == 3) {
                int sourceRow = matrix.inputHandler.getValidRow("Enter the source row: ", matrix.getRows());
                int targetRow = matrix.inputHandler.getValidRow("Enter the target row: ", matrix.getRows());
                double multiplier = matrix.inputHandler.getDoubleInput("Enter the multiplier for the source row: ");
                matrix.addRows(sourceRow, targetRow, multiplier);
                operationSummary += operationCount + ". Multiplied Row " + (sourceRow + 1) + " by " + multiplier + ", and added it to Row " + (targetRow + 1) + ".\n";
            } else if (choice == 4) {
                exit = true;
            }

            System.out.println("Updated matrix:");
            System.out.println(matrix);
        }

        return operationSummary;
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();
        result.append("Rows: ").append(getRows()).append("\n");
        result.append("Columns: ").append(getCols()).append("\n");

        for (int row = 0; row < getRows(); row++) {
            result.append("| ");
            for (int col = 0; col < getCols(); col++) {
                result.append(matrix[row][col]).append(" ");
            }
            result.append("| \n");
        }

        return result.toString();
    }

    private boolean isValidRow(int row) {
        return row >= 0 && row < getRows();
    }

    private boolean isValidColumn(int col) {
        return col >= 0 && col < getCols();
    }
}