import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            MatrixInputHandler inputHandler = new MatrixInputHandler(scanner);

            int numRows = inputHandler.getPositiveIntInput("Enter the number of rows: ");
            int numCols = inputHandler.getPositiveIntInput("Enter the number of columns: ");

            Matrix matrix = new Matrix(numRows, numCols, scanner);

            String operationSummary = Matrix.performMatrixOperations(matrix);

            displayOperationSummary(matrix, operationSummary);
        }
    }

    private static void displayOperationSummary(Matrix matrix, String operationSummary) {
        System.out.println("\n");
        System.out.println("Final Matrix:");
        System.out.println(matrix);
        System.out.println("\n");
        System.out.println(operationSummary);
    }
}