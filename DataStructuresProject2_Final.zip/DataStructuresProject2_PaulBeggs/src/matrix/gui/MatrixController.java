package matrix.gui;

import javafx.geometry.Pos;
import javafx.scene.layout.GridPane;
import matrix.model.Matrix;
import javafx.fxml.FXML;

import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.util.ArrayList;
import java.util.List;

public class MatrixController {
    @FXML
    Button generateButton;
    @FXML
    Button swapButton;
    @FXML
    TextField sizeColsField;
    @FXML
    TextField sizeRowsField;
    @FXML
    TextField targetRow;
    @FXML
    TextField sourceRow;

    public Matrix computationalMatrix;

    @FXML
    GridPane matrix = new GridPane();
    @FXML
    TextField directions;
    private List<List<TextField>> matrixTextFields;

    @FXML
    private void initialize() {
        sizeColsField.setEditable(false);
        sizeRowsField.setEditable(false);
        directions.setEditable(false);
        directions.setText("Click 'generate' to produce a Matrix. The cells are editable;" +
                " use 'tab' to go through each cell and add an entry.");
    }

    @FXML
    public void handleGenerateButton() {
        int numRows = Integer.parseInt(sizeRowsField.getText());
        int numCols = Integer.parseInt(sizeColsField.getText());
        computationalMatrix = new Matrix(numRows, numCols);

        matrixTextFields = new ArrayList<>();

        for (int row = 0; row < numRows; row++) {
            List<TextField> rowList = new ArrayList<>();
            for (int col = 0; col < numCols; col++) {
                TextField tf = new TextField();
                tf.setPrefHeight(100);
                tf.setPrefWidth(150);
                tf.setAlignment(Pos.CENTER);
                tf.setEditable(true);
                tf.setText("0");
                matrix.add(tf, col, row);

                rowList.add(tf);
            }
            matrixTextFields.add(rowList);
        }
    }

    @FXML
    public void handleSwapRows() {
        int numCols = computationalMatrix.getCols();
        try {
            int targetRowIndex = Integer.parseInt(targetRow.getText()) - 1;
            int sourceRowIndex = Integer.parseInt(sourceRow.getText()) - 1;

            if (computationalMatrix.isValidRow(targetRowIndex) && computationalMatrix.isValidRow(sourceRowIndex)) {
                computationalMatrix.swapRows(targetRowIndex, sourceRowIndex);
                for (int col = 0; col < numCols; col++) {
                    String temp = matrixTextFields.get(targetRowIndex).get(col).getText();
                    matrixTextFields.get(targetRowIndex).get(col).setText(matrixTextFields.get(sourceRowIndex).get(col).getText());
                    matrixTextFields.get(sourceRowIndex).get(col).setText(temp);
                }
            } else {
                System.out.println("Invalid row indices.");
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter an integer.");
        }
    }
}
