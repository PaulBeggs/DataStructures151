class RowAddition {
    public static void addRows(double[][] matrix, int sourceRow, int targetRow, double multiplier) {
        for (int i = 0; i < matrix[0].length; i++) {
            matrix[targetRow][i] += multiplier * matrix[sourceRow][i];
        }
    }
}