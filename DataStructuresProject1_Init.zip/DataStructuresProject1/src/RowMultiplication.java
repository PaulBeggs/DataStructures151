class RowMultiplication {
    public static void multiplyRow(double[][] matrix, int row, double multiplier) {
        for (int i = 0; i < matrix[0].length; i++) {
            matrix[row][i] *= multiplier;
        }
    }
}