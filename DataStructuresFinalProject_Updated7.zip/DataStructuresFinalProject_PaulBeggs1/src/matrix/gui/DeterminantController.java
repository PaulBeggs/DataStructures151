package matrix.gui;

import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import matrix.model.Matrix;
import matrix.model.MatrixFileHandler;
import matrix.model.MatrixView;
import matrix.operators.MatrixDeterminantOperations;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class DeterminantController implements DataManipulation {

    DecimalFormat decimalFormat = new DecimalFormat("#.##");
    @FXML
    Button saveButton, loadButton;
    @FXML
    TextField targetRow, sourceRow, determinantValue;
    @FXML
    GridPane matrixGrid = new GridPane();
    @FXML
    ChoiceBox<Scenes> scenes;
    private int numRows, numCols;
    private MatrixView matrixView;
    private Matrix matrix;
    private final String matrixFileName = "matrices/matrix_data.txt";


    @FXML
    private void initialize() {
        Matrix matrix = MatrixFileHandler.getMatrix("main_scene_matrix");
        this.matrixView = new MatrixView(matrix);
        matrixView.displayOnGridPane(matrixGrid, false);

        scenes.getItems().setAll(Scenes.values());
        scenes.setValue(Scenes.DETERMINANT);

        scenes.setOnAction(event -> {
            Scenes selectedScene = scenes.getValue();
            try {
                selectedScene.switchScene(event);
            } catch (IOException e) {
                e.getMessage();
            }
        });

        loadMatrixFromFile();
    }

    @FXML
    public void handleDeterminantFunctionality() {
        Matrix matrix = MatrixFileHandler.getMatrix("main_scene_matrix");
        System.out.println("2nd Matrix: \n" + matrix + "\n");

        if (matrix != null) {
            MatrixDeterminantOperations determinantOperations = new MatrixDeterminantOperations(matrix);
            double determinant = determinantOperations.calculateDeterminant();
            determinantValue.setText(Double.toString(Double.parseDouble(decimalFormat.format(determinant))));
            System.out.println("Determinant: " + decimalFormat.format(determinant));
        } else {
            System.out.println("Matrix not found. Generate a matrix first.");
        }
    }

    @Override
    public void handleSaveButton() {

    }

    @Override
    public void handleLoadButton() {

    }

    @Override
    public void onChange() {

    }

    @Override
    public void loadMatrixFromFile() {
        List<List<String>> matrixData = MatrixFileHandler.loadMatrixFromFile(matrixFileName);
        if (matrixData != null) {
            if (!matrixData.isEmpty() && !matrixData.get(0).isEmpty()) {
                matrix = new Matrix(matrixData.size(), matrixData.get(0).size());
            } else {
                System.out.println("Error: matrixData is empty.");
            }
            System.out.println("2nd matrix data: \n" + matrixData);
            populateMatrixFromData();
            MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
        }
    }

    @Override
    public void populateMatrixFromData() {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(matrixFileName));
            matrixGrid.getChildren().clear();
            numRows = 0;
            numCols = 0;

                // Read the file line by line to determine the dimensions
                String line;
                while ((line = br.readLine()) != null) {
                    numRows++; // Increment row count for each line

                    // Split the line to count columns
                    String[] values = line.split("\\s+");
                    numCols = Math.max(numCols, values.length);
                }

                // Create a new Matrix with dimensions of Text File
                matrix = new Matrix(numRows, numCols);

                // Reset the BufferedReader to read from the file again
                br.close();
                br = new BufferedReader(new FileReader(matrixFileName));

                for (int row = 0; row < numRows; row++) {
                    List<TextField> rowList = new ArrayList<>();
                    line = br.readLine();
                    String[] values = line.split("\\s+");

                    for (int col = 0; col < numCols; col++) {
                        TextField cell = new TextField();
                        cell.setMinHeight(50);
                        cell.setMinWidth(50);
                        cell.setAlignment(Pos.CENTER);
                        cell.setEditable(false);

                        cell.setText(values[col]);
                        matrix.setValue(row, col, Double.parseDouble(values[col]));

                        cell.textProperty().addListener((observable, oldValue, newValue) -> {
                            if (!newValue.matches("\\d*(\\.\\d*)?")) {
                                cell.setText(newValue.replaceAll("[^\\d.]", ""));
                            }
                        });

                        matrixGrid.add(cell, col, row);
                        rowList.add(cell);
                    }
                }

                System.out.println("Before Setting: \n" + matrix);
                MatrixFileHandler.setMatrix("main_scene_matrix", matrix);
                System.out.println("After Setting: \n" + MatrixFileHandler.getMatrix("main_scene_matrix"));

        } catch (IOException e) {
            throw new RuntimeException(e);

        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    public void saveMatrixToFile() {

    }
}


