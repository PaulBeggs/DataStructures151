package matrix.gui;

import javafx.scene.control.TextField;
import matrix.model.MatrixFileHandler;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public interface DataManipulation {
    void handleSaveButton();
    void handleLoadButton();
    void onChange();
    void loadMatrixFromFile();
    void populateMatrixFromData();
    void saveMatrixToFile();
}
