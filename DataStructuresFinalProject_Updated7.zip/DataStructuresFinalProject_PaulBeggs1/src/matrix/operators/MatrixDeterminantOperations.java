package matrix.operators;

import matrix.model.Matrix;

import java.math.BigDecimal;

//
public class MatrixDeterminantOperations {

    private Matrix matrix;

    public MatrixDeterminantOperations(Matrix matrix) {
        this.matrix = matrix;
    }

    public double calculateDeterminant() {
        double[][] matrixArray = matrix.getMatrix();
        int rows = matrix.getRows();
        int cols = matrix.getCols();

        if (rows != cols) {
            System.out.println("Determinant is not defined for non-square matrices.");
            return 0;
        }

        double[][] tempMatrix = new double[rows][cols];
        for (int i = 0; i < rows; i++) {
            System.arraycopy(matrixArray[i], 0, tempMatrix[i], 0, cols);
        }

        DeterminantCalc determinantCalc = new DeterminantCalc(tempMatrix);
        BigDecimal determinant = determinantCalc.determinant();
        return determinant.doubleValue();
    }
}
